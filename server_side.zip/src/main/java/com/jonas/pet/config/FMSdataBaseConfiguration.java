package com.jonas.pet.config;



import com.zaxxer.hikari.HikariDataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Configuration
@EnableJpaRepositories(basePackages = "com.jonas.pet.rep.fms",
        entityManagerFactoryRef = "fmsEntityManagerFactory",
        transactionManagerRef= "fmsTransactionManager")
public class FMSdataBaseConfiguration {

    @Bean
    @Primary
    @ConfigurationProperties("app.datasource.fms")
    public DataSourceProperties fmsDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @Primary
    @ConfigurationProperties("app.datasource.fms.configuration")
    public DataSource fmsDataSource() {
        return fmsDataSourceProperties().initializeDataSourceBuilder()
                .type(HikariDataSource.class).build();
    }

    @Primary
    @Bean(name = "fmsEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean fmsEntityManagerFactory(
            EntityManagerFactoryBuilder builder) {
        Map<String, Object> properties = new HashMap<String, Object>();
        properties.put("spring.jpa.hibernate.ddl-auto", "none");
        return builder
                .dataSource(fmsDataSource())
                .packages("com.jonas.pet.model.fms")
                .properties(properties)
                .build();
    }

    @Primary
    @Bean
    public PlatformTransactionManager fmsTransactionManager(
            final @Qualifier("fmsEntityManagerFactory") LocalContainerEntityManagerFactoryBean fmsEntityManagerFactory) {
        return new JpaTransactionManager(Objects.requireNonNull(fmsEntityManagerFactory.getObject()));
    }

}
