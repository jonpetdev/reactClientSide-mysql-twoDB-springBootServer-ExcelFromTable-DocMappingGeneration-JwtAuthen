package com.jonas.pet.service.impl;


import com.jonas.pet.model.fms.NfqObject;
import com.jonas.pet.model.longShort.ObjectoInfoShort;
import com.jonas.pet.model.user.TariffDB;
import com.jonas.pet.rep.fms.BusinessUnitRep;
import com.jonas.pet.rep.fms.ObjectRep;
import com.jonas.pet.rep.fms.TicketRep;
import com.jonas.pet.rep.user.TariffRep;
import com.jonas.pet.service.ObjektoInfoService;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class ObjektoInfoImpl implements ObjektoInfoService {

    @Autowired
    private TicketRep ticketRep;

    @Autowired
    private BusinessUnitRep businessUnitRep;

    @Autowired
    private ObjectRep objectRep;

    @Autowired
    private TariffRep tariffRep;

    @Override
    public List<ObjectoInfoShort> getAllForShortTermPlan(Integer objectId, Integer year) throws IOException, InvalidFormatException {
        List<ObjectoInfoShort> list = new ArrayList<>();
        ObjectoInfoShort obj = new ObjectoInfoShort();
        NfqObject objektas = objectRep.getOne(objectId);
        TariffDB tariff = tariffRep.findByHouseExternalIDAndBusinessUnitInternalIDAndYear(objektas.getExternalId(), objektas.getBusinessUnitId(), year);

        obj.setOroBusinessUnit(businessUnitRep.getOne(objektas.getBusinessUnitId()));
        obj.setNfqObject(objektas);
        obj.setTotalArea(objektas.getArea());
        obj.setPlanningTickets(ticketRep.findShortTerm(objectId));

        List<Integer> flatTypeId = new ArrayList<>();
        Collections.addAll(flatTypeId, 4,11,18,25,32,39,46,58);
        List<Integer> nonFlatTypeId = new ArrayList<>();
        Collections.addAll(nonFlatTypeId, 2,3,5,9,10,12,16,17,19,23,24,26,30,31,33,37,38,40,44,45,47,56,57,59);

        obj.setFlatCount(objectRep.countByHouseIdAndTypeIdIn(objectId, flatTypeId));
        obj.setNonFlatCount(objectRep.countByHouseIdAndTypeIdIn(objectId, nonFlatTypeId));


        obj.setTariff(tariff);
        list.add(obj);

        return list;
    }

    @Override
    public List<ObjectoInfoShort> getAllForLongTermPlan(Integer objectId, Date dateTo, Integer year) throws IOException, InvalidFormatException {
        List<ObjectoInfoShort> listLong = new ArrayList<>();
        ObjectoInfoShort obj = new ObjectoInfoShort();
        NfqObject objektas = objectRep.getOne(objectId);
        TariffDB tariff = tariffRep.findByHouseExternalIDAndBusinessUnitInternalIDAndYear(objektas.getExternalId(), objektas.getBusinessUnitId(), year);

        obj.setOroBusinessUnit(businessUnitRep.getOne(objektas.getBusinessUnitId()));
        obj.setNfqObject(objektas);
        obj.setTotalArea(objektas.getArea());

        obj.setPlanningTickets(ticketRep.findLongTerm(objectId,dateTo));

        List<Integer> flatTypeIdLong = new ArrayList<>();
        Collections.addAll(flatTypeIdLong, 4,11,18,25,32,39,46,58);

        List<Integer> nonFlatTypeIdLong = new ArrayList<>();
        Collections.addAll(nonFlatTypeIdLong, 2,3,5,9,10,12,16,17,19,23,24,26,30,31,33,37,38,40,44,45,47,56,57,59);


        obj.setFlatCount(objectRep.countByHouseIdAndTypeIdIn(objectId, flatTypeIdLong));
        obj.setNonFlatCount(objectRep.countByHouseIdAndTypeIdIn(objectId,  nonFlatTypeIdLong));


        obj.setTariff(tariff);
        listLong.add(obj);

        return listLong;
    }
}
