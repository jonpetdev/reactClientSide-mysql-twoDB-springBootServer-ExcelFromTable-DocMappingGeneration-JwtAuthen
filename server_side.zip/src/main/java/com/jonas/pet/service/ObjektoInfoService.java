package com.jonas.pet.service;


import com.jonas.pet.model.longShort.ObjectoInfoShort;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

public interface ObjektoInfoService {

    List<ObjectoInfoShort> getAllForShortTermPlan(Integer objectId, Integer year) throws IOException, InvalidFormatException;

    List<ObjectoInfoShort> getAllForLongTermPlan(Integer objectId, Date dateTo, Integer year) throws IOException, InvalidFormatException;
}
