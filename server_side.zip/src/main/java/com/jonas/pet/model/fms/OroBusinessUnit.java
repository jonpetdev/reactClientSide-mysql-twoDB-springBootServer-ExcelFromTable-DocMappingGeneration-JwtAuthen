package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "oro_business_unit", schema = "platform", catalog = "")
public class OroBusinessUnit {
    private int id;
    private Integer businessUnitOwnerId;
    private String name;
    private String phone;
    private String website;
    private String email;
    private String fax;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private String extendDescription;
    private String billingSystemCode;
    private String serializedData;
    private String address;
    private String companyCode;
    private String vatCode;
    private String bankAccount;
    private String type;
    private String mailChimpListId;
    private String neoPayProjectId;
    private String neoPayKey;
    private String bbFullName;
    private Collection<NfqObject> nfqObjectsById;
    private Collection<NfqTask> nfqTasksById;
    private Collection<NfqTicket> nfqTicketsById;
    private OroBusinessUnit oroBusinessUnitByBusinessUnitOwnerId;
    private Collection<OroUser> oroUsersById;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "business_unit_owner_id", nullable = true)
    public Integer getBusinessUnitOwnerId() {
        return businessUnitOwnerId;
    }

    public void setBusinessUnitOwnerId(Integer businessUnitOwnerId) {
        this.businessUnitOwnerId = businessUnitOwnerId;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "phone", nullable = true, length = 100)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "website", nullable = true, length = 255)
    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    @Basic
    @Column(name = "email", nullable = true, length = 255)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "fax", nullable = true, length = 255)
    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    @Basic
    @Column(name = "created_at", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updated_at", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "extend_description", nullable = true, length = -1)
    public String getExtendDescription() {
        return extendDescription;
    }

    public void setExtendDescription(String extendDescription) {
        this.extendDescription = extendDescription;
    }

    @Basic
    @Column(name = "billing_system_code", nullable = true, length = 255)
    public String getBillingSystemCode() {
        return billingSystemCode;
    }

    public void setBillingSystemCode(String billingSystemCode) {
        this.billingSystemCode = billingSystemCode;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Basic
    @Column(name = "address", nullable = true, length = 255)
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Basic
    @Column(name = "companycode", nullable = true, length = 255)
    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    @Basic
    @Column(name = "vatcode", nullable = true, length = 255)
    public String getVatCode() {
        return vatCode;
    }

    public void setVatCode(String vatCode) {
        this.vatCode = vatCode;
    }

    @Basic
    @Column(name = "bankaccount", nullable = true, length = 255)
    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    @Basic
    @Column(name = "type", nullable = true, length = 255)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "mail_chimp_list_id", nullable = true, length = 255)
    public String getMailChimpListId() {
        return mailChimpListId;
    }

    public void setMailChimpListId(String mailChimpListId) {
        this.mailChimpListId = mailChimpListId;
    }

    @Basic
    @Column(name = "neo_pay_project_id", nullable = true, length = 255)
    public String getNeoPayProjectId() {
        return neoPayProjectId;
    }

    public void setNeoPayProjectId(String neoPayProjectId) {
        this.neoPayProjectId = neoPayProjectId;
    }

    @Basic
    @Column(name = "neo_pay_key", nullable = true, length = 255)
    public String getNeoPayKey() {
        return neoPayKey;
    }

    public void setNeoPayKey(String neoPayKey) {
        this.neoPayKey = neoPayKey;
    }

    @Basic
    @Column(name = "bb_full_name", nullable = true, length = 255)
    public String getBbFullName() {
        return bbFullName;
    }

    public void setBbFullName(String bbFullName) {
        this.bbFullName = bbFullName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OroBusinessUnit that = (OroBusinessUnit) o;

        if (id != that.id) return false;
        if (businessUnitOwnerId != null ? !businessUnitOwnerId.equals(that.businessUnitOwnerId) : that.businessUnitOwnerId != null)
            return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (phone != null ? !phone.equals(that.phone) : that.phone != null) return false;
        if (website != null ? !website.equals(that.website) : that.website != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (fax != null ? !fax.equals(that.fax) : that.fax != null) return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(that.updatedAt) : that.updatedAt != null) return false;
        if (extendDescription != null ? !extendDescription.equals(that.extendDescription) : that.extendDescription != null)
            return false;
        if (billingSystemCode != null ? !billingSystemCode.equals(that.billingSystemCode) : that.billingSystemCode != null)
            return false;
        if (serializedData != null ? !serializedData.equals(that.serializedData) : that.serializedData != null)
            return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (companyCode != null ? !companyCode.equals(that.companyCode) : that.companyCode != null) return false;
        if (vatCode != null ? !vatCode.equals(that.vatCode) : that.vatCode != null) return false;
        if (bankAccount != null ? !bankAccount.equals(that.bankAccount) : that.bankAccount != null) return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (mailChimpListId != null ? !mailChimpListId.equals(that.mailChimpListId) : that.mailChimpListId != null)
            return false;
        if (neoPayProjectId != null ? !neoPayProjectId.equals(that.neoPayProjectId) : that.neoPayProjectId != null)
            return false;
        if (neoPayKey != null ? !neoPayKey.equals(that.neoPayKey) : that.neoPayKey != null) return false;
        if (bbFullName != null ? !bbFullName.equals(that.bbFullName) : that.bbFullName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (businessUnitOwnerId != null ? businessUnitOwnerId.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (website != null ? website.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (fax != null ? fax.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (extendDescription != null ? extendDescription.hashCode() : 0);
        result = 31 * result + (billingSystemCode != null ? billingSystemCode.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (companyCode != null ? companyCode.hashCode() : 0);
        result = 31 * result + (vatCode != null ? vatCode.hashCode() : 0);
        result = 31 * result + (bankAccount != null ? bankAccount.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (mailChimpListId != null ? mailChimpListId.hashCode() : 0);
        result = 31 * result + (neoPayProjectId != null ? neoPayProjectId.hashCode() : 0);
        result = 31 * result + (neoPayKey != null ? neoPayKey.hashCode() : 0);
        result = 31 * result + (bbFullName != null ? bbFullName.hashCode() : 0);
        return result;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroBusinessUnitByBusinessUnitId")
    public Collection<NfqObject> getNfqObjectsById() {
        return nfqObjectsById;
    }

    public void setNfqObjectsById(Collection<NfqObject> nfqObjectsById) {
        this.nfqObjectsById = nfqObjectsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroBusinessUnitByBusinessUnitId")
    public Collection<NfqTask> getNfqTasksById() {
        return nfqTasksById;
    }

    public void setNfqTasksById(Collection<NfqTask> nfqTasksById) {
        this.nfqTasksById = nfqTasksById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroBusinessUnitByBusinessUnitId")
    public Collection<NfqTicket> getNfqTicketsById() {
        return nfqTicketsById;
    }

    public void setNfqTicketsById(Collection<NfqTicket> nfqTicketsById) {
        this.nfqTicketsById = nfqTicketsById;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_unit_owner_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroBusinessUnit getOroBusinessUnitByBusinessUnitOwnerId() {
        return oroBusinessUnitByBusinessUnitOwnerId;
    }

    public void setOroBusinessUnitByBusinessUnitOwnerId(OroBusinessUnit oroBusinessUnitByBusinessUnitOwnerId) {
        this.oroBusinessUnitByBusinessUnitOwnerId = oroBusinessUnitByBusinessUnitOwnerId;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroBusinessUnitByBusinessUnitOwnerId")
    public Collection<OroUser> getOroUsersById() {
        return oroUsersById;
    }

    public void setOroUsersById(Collection<OroUser> oroUsersById) {
        this.oroUsersById = oroUsersById;
    }
}
