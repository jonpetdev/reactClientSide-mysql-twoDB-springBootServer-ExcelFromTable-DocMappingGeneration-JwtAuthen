package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "nfq_employee", schema = "platform",  indexes = {
        @Index(name = "IDX_8E0AEFCBA9D1C132C808Ba5A", columnList = "first_name, last_name", unique = false),
        @Index(name = "UNIQ_8E0AEFCBA76ED395", columnList = "user_id")
})
public class NfqEmployee {
    @JsonIgnore
    private int id;
    @JsonIgnore
    private Integer userId;
    @JsonIgnore
    private Integer headId;

    private String firstName;
    private String lastName;
    @JsonIgnore
    private String phone;
    @JsonIgnore
    private Timestamp startedWork;
    @JsonIgnore
    private Timestamp endWork;
    @JsonIgnore
    private Timestamp birthday;
    @JsonIgnore
    private String timeCardNo;
    @JsonIgnore
    private String personalNo;
    @JsonIgnore
    private String address;
    @JsonIgnore
    private byte isActive;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    @JsonIgnore
    private String email;
    @JsonIgnore
    private String serializedData;
    @JsonIgnore
    private String appointmentReason;
    @JsonIgnore
    private String eSignId;
    @JsonIgnore
    private OroUser oroUserByUserId;
    @JsonIgnore
    private NfqEmployee nfqEmployeeByHeadId;

    private Collection<NfqObject> nfqObjectsById;
    private Collection<NfqObject> nfqObjectsById_0;
    private Collection<NfqObject> nfqObjectsById_1;
    private Collection<NfqObject> nfqObjectsById_2;
    private Collection<NfqObject> nfqObjectsById_3;
    private Collection<NfqTaskAssistant> nfqTaskAssistantsById;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id", nullable = true)
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "head_id", nullable = true)
    public Integer getHeadId() {
        return headId;
    }

    public void setHeadId(Integer headId) {
        this.headId = headId;
    }

    @Basic
    @Column(name = "first_name", nullable = false, length = 64)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "last_name", nullable = false, length = 64)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "phone", nullable = true, length = 32)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "started_work", nullable = false)
    public Timestamp getStartedWork() {
        return startedWork;
    }

    public void setStartedWork(Timestamp startedWork) {
        this.startedWork = startedWork;
    }

    @Basic
    @Column(name = "end_work", nullable = true)
    public Timestamp getEndWork() {
        return endWork;
    }

    public void setEndWork(Timestamp endWork) {
        this.endWork = endWork;
    }

    @Basic
    @Column(name = "birthday", nullable = true)
    public Timestamp getBirthday() {
        return birthday;
    }

    public void setBirthday(Timestamp birthday) {
        this.birthday = birthday;
    }

    @Basic
    @Column(name = "time_card_no", nullable = true, length = 255)
    public String getTimeCardNo() {
        return timeCardNo;
    }

    public void setTimeCardNo(String timeCardNo) {
        this.timeCardNo = timeCardNo;
    }

    @Basic
    @Column(name = "personal_no", nullable = true, length = 255)
    public String getPersonalNo() {
        return personalNo;
    }

    public void setPersonalNo(String personalNo) {
        this.personalNo = personalNo;
    }

    @Basic
    @Column(name = "address", nullable = true, length = 255)
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Basic
    @Column(name = "is_active", nullable = false)
    public byte getIsActive() {
        return isActive;
    }

    public void setIsActive(byte isActive) {
        this.isActive = isActive;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "email", nullable = true, length = 128)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Basic
    @Column(name = "appointment_reason", nullable = true, length = 255)
    public String getAppointmentReason() {
        return appointmentReason;
    }

    public void setAppointmentReason(String appointmentReason) {
        this.appointmentReason = appointmentReason;
    }

    @Basic
    @Column(name = "e_sign_id", nullable = true, length = 255)
    public String geteSignId() {
        return eSignId;
    }

    public void seteSignId(String eSignId) {
        this.eSignId = eSignId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqEmployee that = (NfqEmployee) o;

        if (id != that.id) return false;
        if (isActive != that.isActive) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        if (headId != null ? !headId.equals(that.headId) : that.headId != null) return false;
        if (firstName != null ? !firstName.equals(that.firstName) : that.firstName != null) return false;
        if (lastName != null ? !lastName.equals(that.lastName) : that.lastName != null) return false;
        if (phone != null ? !phone.equals(that.phone) : that.phone != null) return false;
        if (startedWork != null ? !startedWork.equals(that.startedWork) : that.startedWork != null) return false;
        if (endWork != null ? !endWork.equals(that.endWork) : that.endWork != null) return false;
        if (birthday != null ? !birthday.equals(that.birthday) : that.birthday != null) return false;
        if (timeCardNo != null ? !timeCardNo.equals(that.timeCardNo) : that.timeCardNo != null) return false;
        if (personalNo != null ? !personalNo.equals(that.personalNo) : that.personalNo != null) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(that.updatedAt) : that.updatedAt != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (serializedData != null ? !serializedData.equals(that.serializedData) : that.serializedData != null)
            return false;
        if (appointmentReason != null ? !appointmentReason.equals(that.appointmentReason) : that.appointmentReason != null)
            return false;
        if (eSignId != null ? !eSignId.equals(that.eSignId) : that.eSignId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (headId != null ? headId.hashCode() : 0);
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (startedWork != null ? startedWork.hashCode() : 0);
        result = 31 * result + (endWork != null ? endWork.hashCode() : 0);
        result = 31 * result + (birthday != null ? birthday.hashCode() : 0);
        result = 31 * result + (timeCardNo != null ? timeCardNo.hashCode() : 0);
        result = 31 * result + (personalNo != null ? personalNo.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (int) isActive;
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        result = 31 * result + (appointmentReason != null ? appointmentReason.hashCode() : 0);
        result = 31 * result + (eSignId != null ? eSignId.hashCode() : 0);
        return result;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByUserId() {
        return oroUserByUserId;
    }

    public void setOroUserByUserId(OroUser oroUserByUserId) {
        this.oroUserByUserId = oroUserByUserId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "head_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByHeadId() {
        return nfqEmployeeByHeadId;
    }

    public void setNfqEmployeeByHeadId(NfqEmployee nfqEmployeeByHeadId) {
        this.nfqEmployeeByHeadId = nfqEmployeeByHeadId;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByTechnicalManagerId")
    public Collection<NfqObject> getNfqObjectsById() {
        return nfqObjectsById;
    }

    public void setNfqObjectsById(Collection<NfqObject> nfqObjectsById) {
        this.nfqObjectsById = nfqObjectsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByAssistantId")
    public Collection<NfqObject> getNfqObjectsById_0() {
        return nfqObjectsById_0;
    }

    public void setNfqObjectsById_0(Collection<NfqObject> nfqObjectsById_0) {
        this.nfqObjectsById_0 = nfqObjectsById_0;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByHeadManagerId")
    public Collection<NfqObject> getNfqObjectsById_1() {
        return nfqObjectsById_1;
    }

    public void setNfqObjectsById_1(Collection<NfqObject> nfqObjectsById_1) {
        this.nfqObjectsById_1 = nfqObjectsById_1;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByAccountantId")
    public Collection<NfqObject> getNfqObjectsById_2() {
        return nfqObjectsById_2;
    }

    public void setNfqObjectsById_2(Collection<NfqObject> nfqObjectsById_2) {
        this.nfqObjectsById_2 = nfqObjectsById_2;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByLawyerId")
    public Collection<NfqObject> getNfqObjectsById_3() {
        return nfqObjectsById_3;
    }

    public void setNfqObjectsById_3(Collection<NfqObject> nfqObjectsById_3) {
        this.nfqObjectsById_3 = nfqObjectsById_3;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqEmployeeByEmployeeId")
    public Collection<NfqTaskAssistant> getNfqTaskAssistantsById() {
        return nfqTaskAssistantsById;
    }

    public void setNfqTaskAssistantsById(Collection<NfqTaskAssistant> nfqTaskAssistantsById) {
        this.nfqTaskAssistantsById = nfqTaskAssistantsById;
    }
}
