package com.jonas.pet.model.user;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "tariff", schema = "user_db")
@Data
public class TariffDB {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="year", nullable = false)
    private Integer year;

    @Column(name = "house_address", nullable = false)
    private String houseAddress;

    @Column(name="benrdas_plotas", nullable = true)
    private BigDecimal bendrasPlotas;

    @Column(name="zemes_sklypo_plotas", nullable = true)
    private BigDecimal zemesSklypoPlotas;

    @Column(name="registracijos_data", nullable = true)
    private String registacijosData;

    @Column(name = "common_use_administration_tariff", nullable = false)
    private BigDecimal commonUseAdministrationTariff;

    @Column(name = "maintenance_tariff")
    private BigDecimal maintenanceTariff;

    @Column(name = "heating_and_heating_system_maintenance_tariff")
    private BigDecimal heatingAndHeatingSystemMaintenanceTariff;

    @Column(name= "elevator_electricity_tariff")
    private BigDecimal elevatorElectricityTariff;

    @Column(name= "elevator_maintenance_tariff")
    private BigDecimal elevatorMaintenanceTariff;

    @Column(name = "electricity_for_common_usage_tariff")
    private BigDecimal electricityForCommonUsageTariff;

    @Column(name = "common_premises_pleaning_tariff")
    private BigDecimal commonPremisesCleaningTariff;

    @Column(name = "territory_maintenance_tariff")
    private BigDecimal territoryMaintenanceTariff;

    @Column(name = "other_services_tariff")
    private BigDecimal otherServicesTariff;

    @Column(name = "accumulated_fund_tariff")
    private BigDecimal accumulatedFundTariff;

    @Column(name = "accumulated_fund_balance")
    private BigDecimal accumulatedFundBalance;

    @Column(name = "house_external_id")
    private Integer houseExternalID;

    @Column(name = "business_unit_internal_id")
    private Integer businessUnitInternalID;


    public TariffDB(){}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getHouseAddress() {
        return houseAddress;
    }

    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }

    public BigDecimal getBendrasPlotas() {
        return bendrasPlotas;
    }

    public void setBendrasPlotas(BigDecimal bendrasPlotas) {
        this.bendrasPlotas = bendrasPlotas;
    }


    public BigDecimal getZemesSklypoPlotas() {
        return zemesSklypoPlotas;
    }

    public void setZemesSklypoPlotas(BigDecimal zemesSklypoPlotas) {
        this.zemesSklypoPlotas = zemesSklypoPlotas;
    }

    public String getRegistacijosData() {
        return registacijosData;
    }

    public void setRegistacijosData(String registacijosData) {
        this.registacijosData = registacijosData;
    }

    public BigDecimal getCommonUseAdministrationTariff() {
        return commonUseAdministrationTariff;
    }

    public void setCommonUseAdministrationTariff(BigDecimal commonUseAdministrationTariff) {
        this.commonUseAdministrationTariff = commonUseAdministrationTariff;
    }

    public BigDecimal getMaintenanceTariff() {
        return maintenanceTariff;
    }

    public void setMaintenanceTariff(BigDecimal maintenanceTariff) {
        this.maintenanceTariff = maintenanceTariff;
    }

    public BigDecimal getHeatingAndHeatingSystemMaintenanceTariff() {
        return heatingAndHeatingSystemMaintenanceTariff;
    }

    public void setHeatingAndHeatingSystemMaintenanceTariff(BigDecimal heatingAndHeatingSystemMaintenanceTariff) {
        this.heatingAndHeatingSystemMaintenanceTariff = heatingAndHeatingSystemMaintenanceTariff;
    }

    public BigDecimal getElevatorElectricityTariff() {
        return elevatorElectricityTariff;
    }

    public void setElevatorElectricityTariff(BigDecimal elevatorElectricityTariff) {
        this.elevatorElectricityTariff = elevatorElectricityTariff;
    }

    public BigDecimal getElevatorMaintenanceTariff() {
        return elevatorMaintenanceTariff;
    }

    public void setElevatorMaintenanceTariff(BigDecimal elevatorMaintenanceTariff) {
        this.elevatorMaintenanceTariff = elevatorMaintenanceTariff;
    }

    public BigDecimal getElectricityForCommonUsageTariff() {
        return electricityForCommonUsageTariff;
    }

    public void setElectricityForCommonUsageTariff(BigDecimal electricityForCommonUsageTariff) {
        this.electricityForCommonUsageTariff = electricityForCommonUsageTariff;
    }

    public BigDecimal getCommonPremisesCleaningTariff() {
        return commonPremisesCleaningTariff;
    }

    public void setCommonPremisesCleaningTariff(BigDecimal commonPremisesCleaningTariff) {
        this.commonPremisesCleaningTariff = commonPremisesCleaningTariff;
    }

    public BigDecimal getTerritoryMaintenanceTariff() {
        return territoryMaintenanceTariff;
    }

    public void setTerritoryMaintenanceTariff(BigDecimal territoryMaintenanceTariff) {
        this.territoryMaintenanceTariff = territoryMaintenanceTariff;
    }

    public BigDecimal getOtherServicesTariff() {
        return otherServicesTariff;
    }

    public void setOtherServicesTariff(BigDecimal otherServicesTariff) {
        this.otherServicesTariff = otherServicesTariff;
    }

    public BigDecimal getAccumulatedFundTariff() {
        return accumulatedFundTariff;
    }

    public void setAccumulatedFundTariff(BigDecimal accumulatedFundTariff) {
        this.accumulatedFundTariff = accumulatedFundTariff;
    }

    public BigDecimal getAccumulatedFundBalance() {
        return accumulatedFundBalance;
    }

    public void setAccumulatedFundBalance(BigDecimal accumulatedFundBalance) {
        this.accumulatedFundBalance = accumulatedFundBalance;
    }

    public Integer getHouseExternalID() {
        return houseExternalID;
    }

    public void setHouseExternalID(Integer houseExternalID) {
        this.houseExternalID = houseExternalID;
    }

    public Integer getBusinessUnitInternalID() {
        return businessUnitInternalID;
    }

    public void setBusinessUnitInternalID(Integer businessUnitInternalID) {
        this.businessUnitInternalID = businessUnitInternalID;
    }
}
