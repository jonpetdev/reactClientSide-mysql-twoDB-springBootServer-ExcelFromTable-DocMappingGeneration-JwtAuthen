package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "nfq_ticket", schema = "platform", indexes =
        {@Index(name = "IDX_90D8A0CB232D562B", columnList = "object_id", unique = false),
                @Index(name = "IDX_90D8A0CB635D99B0", columnList = "work_manager_id", unique = false),
                @Index(name = "IDX_90D8A0CB7B00651C", columnList = "status", unique = false),
                @Index(name = "UNIQ_90D8A0CB79F7AF49", columnList = "work_act_number", unique = true)
        })
public class NfqTicket {

    private int id;
    @JsonIgnore
    private Integer assigneeId;
    @JsonIgnore
    private Integer businessUnitId;
    @JsonIgnore
    private Integer objectId;
    @JsonIgnore
    private Integer supervisorId;
    @JsonIgnore
    private String uuid;

    private String title;
    @JsonIgnore
    private int type;
    @JsonIgnore
    private int channel;

    private String description;
    @JsonIgnore
    private Timestamp deadline;

    private String status;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    @JsonIgnore
    private byte isActive;
    @JsonIgnore
    private int contactStatus;

    private String price;
    @JsonIgnore
    private Integer workActCalculatingType;
    @JsonIgnore
    private String billMessage;
    @JsonIgnore
    private String callCenterComment;
    @JsonIgnore
    private int notificationRecipient;
    @JsonIgnore
    private String contactPerson;
    @JsonIgnore
    private Integer fundUsage;
    @JsonIgnore
    private Timestamp completionDate;
    @JsonIgnore
    private Timestamp workActExportDate;

    private BigDecimal actualPrice;
    @JsonIgnore
    private String contactPersonPhone;
    @JsonIgnore
    private Integer notificationType;

    private String workActNumber;

    private String ltFlowCategory;
    @JsonIgnore
    private String serializedData;
    @JsonIgnore
    private Integer workManagerId;
    @JsonIgnore
    private byte isInternal;
    @JsonIgnore
    private String workActExportStatus;
    @JsonIgnore
    private Integer parentId;
    @JsonIgnore
    private Integer lastStartedTaskId;
    @JsonIgnore
    private Integer estimateTaskId;
    @JsonIgnore
    private byte contractorValidationEnabled;
    @JsonIgnore
    private byte billed;
    @JsonIgnore
    private String declineComments;
    @JsonIgnore
    private String reopenComments;

    private Timestamp workDeadline;
    @JsonIgnore
    private byte reopenedAfterApproval;
    @JsonIgnore
    private byte reopenedAfterVerification;
    @JsonIgnore
    private Integer authorId;

    private Collection<NfqTask> nfqTasksById;
    private OroUser oroUserByAssigneeId;
    private OroBusinessUnit oroBusinessUnitByBusinessUnitId;
    private NfqObject nfqObjectByObjectId;
    private OroUser oroUserBySupervisorId;
    private OroUser oroUserByWorkManagerId;
    private NfqTicket nfqTicketByParentId;


    private Collection<NfqTicket> nfqTicketsById;
    private NfqTask nfqTaskByLastStartedTaskId;
    private NfqTask nfqTaskByEstimateTaskId;
    private OroUser oroUserByAuthorId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "assignee_id", nullable = true)
    public Integer getAssigneeId() {
        return assigneeId;
    }

    public void setAssigneeId(Integer assigneeId) {
        this.assigneeId = assigneeId;
    }

    @Basic
    @Column(name = "business_unit_id", nullable = true)
    public Integer getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(Integer businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    @Basic
    @Column(name = "object_id", nullable = true)
    public Integer getObjectId() {
        return objectId;
    }

    public void setObjectId(Integer objectId) {
        this.objectId = objectId;
    }

    @Basic
    @Column(name = "supervisor_id", nullable = true)
    public Integer getSupervisorId() {
        return supervisorId;
    }

    public void setSupervisorId(Integer supervisorId) {
        this.supervisorId = supervisorId;
    }

    @Basic
    @Column(name = "uuid", nullable = false, length = 36)
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Basic
    @Column(name = "title", nullable = true, length = 255)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Basic
    @Column(name = "channel", nullable = false)
    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    @Basic
    @Column(name = "description", nullable = false, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "deadline", nullable = false)
    public Timestamp getDeadline() {
        return deadline;
    }

    public void setDeadline(Timestamp deadline) {
        this.deadline = deadline;
    }

    @Basic
    @Column(name = "status", nullable = false, length = 255)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "is_active", nullable = false)
    public byte getIsActive() {
        return isActive;
    }

    public void setIsActive(byte isActive) {
        this.isActive = isActive;
    }

    @Basic
    @Column(name = "contact_status", nullable = false)
    public int getContactStatus() {
        return contactStatus;
    }

    public void setContactStatus(int contactStatus) {
        this.contactStatus = contactStatus;
    }

    @Basic
    @Column(name = "price", nullable = true, length = 255)
    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Basic
    @Column(name = "work_act_calculating_type", nullable = true)
    public Integer getWorkActCalculatingType() {
        return workActCalculatingType;
    }

    public void setWorkActCalculatingType(Integer workActCalculatingType) {
        this.workActCalculatingType = workActCalculatingType;
    }

    @Basic
    @Column(name = "bill_message", nullable = true, length = -1)
    public String getBillMessage() {
        return billMessage;
    }

    public void setBillMessage(String billMessage) {
        this.billMessage = billMessage;
    }

    @Basic
    @Column(name = "call_center_comment", nullable = true, length = -1)
    public String getCallCenterComment() {
        return callCenterComment;
    }

    public void setCallCenterComment(String callCenterComment) {
        this.callCenterComment = callCenterComment;
    }

    @Basic
    @Column(name = "notification_recipient", nullable = false)
    public int getNotificationRecipient() {
        return notificationRecipient;
    }

    public void setNotificationRecipient(int notificationRecipient) {
        this.notificationRecipient = notificationRecipient;
    }

    @Basic
    @Column(name = "contact_person", nullable = true, length = 255)
    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    @Basic
    @Column(name = "fund_usage", nullable = true)
    public Integer getFundUsage() {
        return fundUsage;
    }

    public void setFundUsage(Integer fundUsage) {
        this.fundUsage = fundUsage;
    }

    @Basic
    @Column(name = "completion_date", nullable = true)
    public Timestamp getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(Timestamp completionDate) {
        this.completionDate = completionDate;
    }

    @Basic
    @Column(name = "work_act_export_date", nullable = true)
    public Timestamp getWorkActExportDate() {
        return workActExportDate;
    }

    public void setWorkActExportDate(Timestamp workActExportDate) {
        this.workActExportDate = workActExportDate;
    }

    @Basic
    @Column(name = "actual_price", nullable = true, precision = 2)
    public BigDecimal getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(BigDecimal actualPrice) {
        this.actualPrice = actualPrice;
    }

    @Basic
    @Column(name = "contact_person_phone", nullable = true, length = 20)
    public String getContactPersonPhone() {
        return contactPersonPhone;
    }

    public void setContactPersonPhone(String contactPersonPhone) {
        this.contactPersonPhone = contactPersonPhone;
    }

    @Basic
    @Column(name = "notification_type", nullable = true)
    public Integer getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(Integer notificationType) {
        this.notificationType = notificationType;
    }

    @Basic
    @Column(name = "work_act_number", nullable = true, length = 255)
    public String getWorkActNumber() {
        return workActNumber;
    }

    public void setWorkActNumber(String workActNumber) {
        this.workActNumber = workActNumber;
    }

    @Basic
    @Column(name = "lt_flow_category", nullable = true, length = 255)
    public String getLtFlowCategory() {
        return ltFlowCategory;
    }

    public void setLtFlowCategory(String ltFlowCategory) {
        this.ltFlowCategory = ltFlowCategory;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Basic
    @Column(name = "work_manager_id", nullable = true)
    public Integer getWorkManagerId() {
        return workManagerId;
    }

    public void setWorkManagerId(Integer workManagerId) {
        this.workManagerId = workManagerId;
    }

    @Basic
    @Column(name = "is_internal", nullable = false)
    public byte getIsInternal() {
        return isInternal;
    }

    public void setIsInternal(byte isInternal) {
        this.isInternal = isInternal;
    }

    @Basic
    @Column(name = "work_act_export_status", nullable = true, length = 255)
    public String getWorkActExportStatus() {
        return workActExportStatus;
    }

    public void setWorkActExportStatus(String workActExportStatus) {
        this.workActExportStatus = workActExportStatus;
    }

    @Basic
    @Column(name = "parent_id", nullable = true)
    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    @Basic
    @Column(name = "last_started_task_id", nullable = true)
    public Integer getLastStartedTaskId() {
        return lastStartedTaskId;
    }

    public void setLastStartedTaskId(Integer lastStartedTaskId) {
        this.lastStartedTaskId = lastStartedTaskId;
    }

    @Basic
    @Column(name = "estimate_task_id", nullable = true)
    public Integer getEstimateTaskId() {
        return estimateTaskId;
    }

    public void setEstimateTaskId(Integer estimateTaskId) {
        this.estimateTaskId = estimateTaskId;
    }

    @Basic
    @Column(name = "contractor_validation_enabled", nullable = false)
    public byte getContractorValidationEnabled() {
        return contractorValidationEnabled;
    }

    public void setContractorValidationEnabled(byte contractorValidationEnabled) {
        this.contractorValidationEnabled = contractorValidationEnabled;
    }

    @Basic
    @Column(name = "billed", nullable = false)
    public byte getBilled() {
        return billed;
    }

    public void setBilled(byte billed) {
        this.billed = billed;
    }

    @Basic
    @Column(name = "decline_comments", nullable = true, length = -1)
    public String getDeclineComments() {
        return declineComments;
    }

    public void setDeclineComments(String declineComments) {
        this.declineComments = declineComments;
    }

    @Basic
    @Column(name = "reopen_comments", nullable = true, length = -1)
    public String getReopenComments() {
        return reopenComments;
    }

    public void setReopenComments(String reopenComments) {
        this.reopenComments = reopenComments;
    }

    @Basic
    @Column(name = "work_deadline", nullable = false)
    public Timestamp getWorkDeadline() {
        return workDeadline;
    }

    public void setWorkDeadline(Timestamp workDeadline) {
        this.workDeadline = workDeadline;
    }

    @Basic
    @Column(name = "reopened_after_approval", nullable = false)
    public byte getReopenedAfterApproval() {
        return reopenedAfterApproval;
    }

    public void setReopenedAfterApproval(byte reopenedAfterApproval) {
        this.reopenedAfterApproval = reopenedAfterApproval;
    }

    @Basic
    @Column(name = "reopened_after_verification", nullable = false)
    public byte getReopenedAfterVerification() {
        return reopenedAfterVerification;
    }

    public void setReopenedAfterVerification(byte reopenedAfterVerification) {
        this.reopenedAfterVerification = reopenedAfterVerification;
    }

    @Basic
    @Column(name = "author_id", nullable = true)
    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqTicket nfqTicket = (NfqTicket) o;

        if (id != nfqTicket.id) return false;
        if (type != nfqTicket.type) return false;
        if (channel != nfqTicket.channel) return false;
        if (isActive != nfqTicket.isActive) return false;
        if (contactStatus != nfqTicket.contactStatus) return false;
        if (notificationRecipient != nfqTicket.notificationRecipient) return false;
        if (isInternal != nfqTicket.isInternal) return false;
        if (contractorValidationEnabled != nfqTicket.contractorValidationEnabled) return false;
        if (billed != nfqTicket.billed) return false;
        if (reopenedAfterApproval != nfqTicket.reopenedAfterApproval) return false;
        if (reopenedAfterVerification != nfqTicket.reopenedAfterVerification) return false;
        if (assigneeId != null ? !assigneeId.equals(nfqTicket.assigneeId) : nfqTicket.assigneeId != null) return false;
        if (businessUnitId != null ? !businessUnitId.equals(nfqTicket.businessUnitId) : nfqTicket.businessUnitId != null)
            return false;
        if (objectId != null ? !objectId.equals(nfqTicket.objectId) : nfqTicket.objectId != null) return false;
        if (supervisorId != null ? !supervisorId.equals(nfqTicket.supervisorId) : nfqTicket.supervisorId != null)
            return false;
        if (uuid != null ? !uuid.equals(nfqTicket.uuid) : nfqTicket.uuid != null) return false;
        if (title != null ? !title.equals(nfqTicket.title) : nfqTicket.title != null) return false;
        if (description != null ? !description.equals(nfqTicket.description) : nfqTicket.description != null)
            return false;
        if (deadline != null ? !deadline.equals(nfqTicket.deadline) : nfqTicket.deadline != null) return false;
        if (status != null ? !status.equals(nfqTicket.status) : nfqTicket.status != null) return false;
        if (createdAt != null ? !createdAt.equals(nfqTicket.createdAt) : nfqTicket.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(nfqTicket.updatedAt) : nfqTicket.updatedAt != null) return false;
        if (price != null ? !price.equals(nfqTicket.price) : nfqTicket.price != null) return false;
        if (workActCalculatingType != null ? !workActCalculatingType.equals(nfqTicket.workActCalculatingType) : nfqTicket.workActCalculatingType != null)
            return false;
        if (billMessage != null ? !billMessage.equals(nfqTicket.billMessage) : nfqTicket.billMessage != null)
            return false;
        if (callCenterComment != null ? !callCenterComment.equals(nfqTicket.callCenterComment) : nfqTicket.callCenterComment != null)
            return false;
        if (contactPerson != null ? !contactPerson.equals(nfqTicket.contactPerson) : nfqTicket.contactPerson != null)
            return false;
        if (fundUsage != null ? !fundUsage.equals(nfqTicket.fundUsage) : nfqTicket.fundUsage != null) return false;
        if (completionDate != null ? !completionDate.equals(nfqTicket.completionDate) : nfqTicket.completionDate != null)
            return false;
        if (workActExportDate != null ? !workActExportDate.equals(nfqTicket.workActExportDate) : nfqTicket.workActExportDate != null)
            return false;
        if (actualPrice != null ? !actualPrice.equals(nfqTicket.actualPrice) : nfqTicket.actualPrice != null)
            return false;
        if (contactPersonPhone != null ? !contactPersonPhone.equals(nfqTicket.contactPersonPhone) : nfqTicket.contactPersonPhone != null)
            return false;
        if (notificationType != null ? !notificationType.equals(nfqTicket.notificationType) : nfqTicket.notificationType != null)
            return false;
        if (workActNumber != null ? !workActNumber.equals(nfqTicket.workActNumber) : nfqTicket.workActNumber != null)
            return false;
        if (ltFlowCategory != null ? !ltFlowCategory.equals(nfqTicket.ltFlowCategory) : nfqTicket.ltFlowCategory != null)
            return false;
        if (serializedData != null ? !serializedData.equals(nfqTicket.serializedData) : nfqTicket.serializedData != null)
            return false;
        if (workManagerId != null ? !workManagerId.equals(nfqTicket.workManagerId) : nfqTicket.workManagerId != null)
            return false;
        if (workActExportStatus != null ? !workActExportStatus.equals(nfqTicket.workActExportStatus) : nfqTicket.workActExportStatus != null)
            return false;
        if (parentId != null ? !parentId.equals(nfqTicket.parentId) : nfqTicket.parentId != null) return false;
        if (lastStartedTaskId != null ? !lastStartedTaskId.equals(nfqTicket.lastStartedTaskId) : nfqTicket.lastStartedTaskId != null)
            return false;
        if (estimateTaskId != null ? !estimateTaskId.equals(nfqTicket.estimateTaskId) : nfqTicket.estimateTaskId != null)
            return false;
        if (declineComments != null ? !declineComments.equals(nfqTicket.declineComments) : nfqTicket.declineComments != null)
            return false;
        if (reopenComments != null ? !reopenComments.equals(nfqTicket.reopenComments) : nfqTicket.reopenComments != null)
            return false;
        if (workDeadline != null ? !workDeadline.equals(nfqTicket.workDeadline) : nfqTicket.workDeadline != null)
            return false;
        if (authorId != null ? !authorId.equals(nfqTicket.authorId) : nfqTicket.authorId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (assigneeId != null ? assigneeId.hashCode() : 0);
        result = 31 * result + (businessUnitId != null ? businessUnitId.hashCode() : 0);
        result = 31 * result + (objectId != null ? objectId.hashCode() : 0);
        result = 31 * result + (supervisorId != null ? supervisorId.hashCode() : 0);
        result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + type;
        result = 31 * result + channel;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (deadline != null ? deadline.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (int) isActive;
        result = 31 * result + contactStatus;
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (workActCalculatingType != null ? workActCalculatingType.hashCode() : 0);
        result = 31 * result + (billMessage != null ? billMessage.hashCode() : 0);
        result = 31 * result + (callCenterComment != null ? callCenterComment.hashCode() : 0);
        result = 31 * result + notificationRecipient;
        result = 31 * result + (contactPerson != null ? contactPerson.hashCode() : 0);
        result = 31 * result + (fundUsage != null ? fundUsage.hashCode() : 0);
        result = 31 * result + (completionDate != null ? completionDate.hashCode() : 0);
        result = 31 * result + (workActExportDate != null ? workActExportDate.hashCode() : 0);
        result = 31 * result + (actualPrice != null ? actualPrice.hashCode() : 0);
        result = 31 * result + (contactPersonPhone != null ? contactPersonPhone.hashCode() : 0);
        result = 31 * result + (notificationType != null ? notificationType.hashCode() : 0);
        result = 31 * result + (workActNumber != null ? workActNumber.hashCode() : 0);
        result = 31 * result + (ltFlowCategory != null ? ltFlowCategory.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        result = 31 * result + (workManagerId != null ? workManagerId.hashCode() : 0);
        result = 31 * result + (int) isInternal;
        result = 31 * result + (workActExportStatus != null ? workActExportStatus.hashCode() : 0);
        result = 31 * result + (parentId != null ? parentId.hashCode() : 0);
        result = 31 * result + (lastStartedTaskId != null ? lastStartedTaskId.hashCode() : 0);
        result = 31 * result + (estimateTaskId != null ? estimateTaskId.hashCode() : 0);
        result = 31 * result + (int) contractorValidationEnabled;
        result = 31 * result + (int) billed;
        result = 31 * result + (declineComments != null ? declineComments.hashCode() : 0);
        result = 31 * result + (reopenComments != null ? reopenComments.hashCode() : 0);
        result = 31 * result + (workDeadline != null ? workDeadline.hashCode() : 0);
        result = 31 * result + (int) reopenedAfterApproval;
        result = 31 * result + (int) reopenedAfterVerification;
        result = 31 * result + (authorId != null ? authorId.hashCode() : 0);
        return result;
    }


    @OneToMany(mappedBy = "nfqTicketByTicketId")
    public Collection<NfqTask> getNfqTasksById() {
        return nfqTasksById;
    }

    public void setNfqTasksById(Collection<NfqTask> nfqTasksById) {
        this.nfqTasksById = nfqTasksById;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByAssigneeId() {
        return oroUserByAssigneeId;
    }

    public void setOroUserByAssigneeId(OroUser oroUserByAssigneeId) {
        this.oroUserByAssigneeId = oroUserByAssigneeId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_unit_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroBusinessUnit getOroBusinessUnitByBusinessUnitId() {
        return oroBusinessUnitByBusinessUnitId;
    }

    public void setOroBusinessUnitByBusinessUnitId(OroBusinessUnit oroBusinessUnitByBusinessUnitId) {
        this.oroBusinessUnitByBusinessUnitId = oroBusinessUnitByBusinessUnitId;
    }


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "object_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqObject getNfqObjectByObjectId() {
        return nfqObjectByObjectId;
    }

    public void setNfqObjectByObjectId(NfqObject nfqObjectByObjectId) {
        this.nfqObjectByObjectId = nfqObjectByObjectId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "supervisor_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserBySupervisorId() {
        return oroUserBySupervisorId;
    }

    public void setOroUserBySupervisorId(OroUser oroUserBySupervisorId) {
        this.oroUserBySupervisorId = oroUserBySupervisorId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "work_manager_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByWorkManagerId() {
        return oroUserByWorkManagerId;
    }

    public void setOroUserByWorkManagerId(OroUser oroUserByWorkManagerId) {
        this.oroUserByWorkManagerId = oroUserByWorkManagerId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqTicket getNfqTicketByParentId() {
        return nfqTicketByParentId;
    }

    public void setNfqTicketByParentId(NfqTicket nfqTicketByParentId) {
        this.nfqTicketByParentId = nfqTicketByParentId;
    }
    @JsonIgnore
    @OneToMany(mappedBy = "nfqTicketByParentId")
    public Collection<NfqTicket> getNfqTicketsById() {
        return nfqTicketsById;
    }

    public void setNfqTicketsById(Collection<NfqTicket> nfqTicketsById) {
        this.nfqTicketsById = nfqTicketsById;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "last_started_task_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqTask getNfqTaskByLastStartedTaskId() {
        return nfqTaskByLastStartedTaskId;
    }

    public void setNfqTaskByLastStartedTaskId(NfqTask nfqTaskByLastStartedTaskId) {
        this.nfqTaskByLastStartedTaskId = nfqTaskByLastStartedTaskId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "estimate_task_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqTask getNfqTaskByEstimateTaskId() {
        return nfqTaskByEstimateTaskId;
    }

    public void setNfqTaskByEstimateTaskId(NfqTask nfqTaskByEstimateTaskId) {
        this.nfqTaskByEstimateTaskId = nfqTaskByEstimateTaskId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByAuthorId() {
        return oroUserByAuthorId;
    }

    public void setOroUserByAuthorId(OroUser oroUserByAuthorId) {
        this.oroUserByAuthorId = oroUserByAuthorId;
    }
}
