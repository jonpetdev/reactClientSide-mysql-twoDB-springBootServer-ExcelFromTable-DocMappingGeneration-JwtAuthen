package com.jonas.pet.model.fms;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public class NfqTaskAssistantPK implements Serializable {
    private int taskId;
    private int employeeId;

    @Column(name = "task_id", nullable = false)
    @Id
    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    @Column(name = "employee_id", nullable = false)
    @Id
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqTaskAssistantPK that = (NfqTaskAssistantPK) o;

        if (taskId != that.taskId) return false;
        if (employeeId != that.employeeId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = taskId;
        result = 31 * result + employeeId;
        return result;
    }
}
