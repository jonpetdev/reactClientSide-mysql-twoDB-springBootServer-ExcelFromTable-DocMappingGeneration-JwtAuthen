package com.jonas.pet.model.longShort;

import com.jonas.pet.model.fms.NfqObject;
import com.jonas.pet.model.fms.NfqTicket;
import com.jonas.pet.model.fms.OroBusinessUnit;
import com.jonas.pet.model.user.TariffDB;

import java.math.BigDecimal;
import java.util.List;

public class ObjectoInfoShort {

    private OroBusinessUnit oroBusinessUnit;
    private NfqObject nfqObject;
    private BigDecimal totalArea;
    private TariffDB tariff;
    private List<NfqTicket> planningTickets;
    private Integer flatCount;
    private Integer nonFlatCount;



    public ObjectoInfoShort(){}

    public Integer getFlatCount() {
        return flatCount;
    }

    public void setFlatCount(Integer flatCount) {
        this.flatCount = flatCount;
    }

    public Integer getNonFlatCount() {
        return nonFlatCount;
    }

    public void setNonFlatCount(Integer nonFlatCount) {
        this.nonFlatCount = nonFlatCount;
    }

    public OroBusinessUnit getOroBusinessUnit() {
        return oroBusinessUnit;
    }

    public void setOroBusinessUnit(OroBusinessUnit oroBusinessUnit) {
        this.oroBusinessUnit = oroBusinessUnit;
    }

    public NfqObject getNfqObject() {
        return nfqObject;
    }

    public void setNfqObject(NfqObject nfqObject) {
        this.nfqObject = nfqObject;
    }


    public BigDecimal getTotalArea() {
        return totalArea;
    }

    public void setTotalArea(BigDecimal totalArea) {
        this.totalArea = totalArea;
    }


    public List<NfqTicket> getPlanningTickets() {
        return planningTickets;
    }

    public void setPlanningTickets(List<NfqTicket> planningTickets) {
        this.planningTickets = planningTickets;
    }


    public TariffDB getTariff() {
        return tariff;
    }

    public void setTariff(TariffDB tariff) {
        this.tariff = tariff;
    }
}
