package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "oro_user", schema = "platform", indexes = {
        @Index(name = "UNIQ_F82840BCF85E0677", columnList = "username", unique = true ),
        @Index(name = "user_first_name_last_name_idx", columnList = "first_name, last_name", unique = false)
})
public class OroUser {

    private int id;
    @JsonIgnore
    private Integer businessUnitOwnerId;
    private String username;

    @JsonIgnore
    private String email;
    @JsonIgnore
    private String phone;
    @JsonIgnore
    private String namePrefix;

    private String firstName;
    @JsonIgnore
    private String middleName;

    private String lastName;
    @JsonIgnore
    private String nameSuffix;
    @JsonIgnore
    private Date birthday;
    @JsonIgnore
    private byte enabled;
    @JsonIgnore
    private String salt;
    @JsonIgnore
    private String password;
    @JsonIgnore
    private String confirmationToken;
    @JsonIgnore
    private Timestamp passwordRequested;
    @JsonIgnore
    private Timestamp lastLogin;
    @JsonIgnore
    private int loginCount;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    @JsonIgnore
    private String title;
    @JsonIgnore
    private Timestamp passwordChanged;
    @JsonIgnore
    private String googleId;
    @JsonIgnore
    private String serializedData;

    private Collection<NfqEmployee> nfqEmployeesById;
    private Collection<NfqTask> nfqTasksById;
    private Collection<NfqTask> nfqTasksById_0;
    private Collection<NfqTaskMaterial> nfqTaskMaterialsById;
    private Collection<NfqTaskMaterial> nfqTaskMaterialsById_0;
    private Collection<NfqTicket> nfqTicketsById;
    private Collection<NfqTicket> nfqTicketsById_0;
    private Collection<NfqTicket> nfqTicketsById_1;
    private Collection<NfqTicket> nfqTicketsById_2;
    private OroBusinessUnit oroBusinessUnitByBusinessUnitOwnerId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "business_unit_owner_id", nullable = true)
    public Integer getBusinessUnitOwnerId() {
        return businessUnitOwnerId;
    }

    public void setBusinessUnitOwnerId(Integer businessUnitOwnerId) {
        this.businessUnitOwnerId = businessUnitOwnerId;
    }

    @Basic
    @Column(name = "username", nullable = false, length = 255)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Basic
    @Column(name = "email", nullable = false, length = 255)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "phone", nullable = true, length = 255)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "name_prefix", nullable = true, length = 255)
    public String getNamePrefix() {
        return namePrefix;
    }

    public void setNamePrefix(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    @Basic
    @Column(name = "first_name", nullable = true, length = 255)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "middle_name", nullable = true, length = 255)
    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @Basic
    @Column(name = "last_name", nullable = true, length = 255)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "name_suffix", nullable = true, length = 255)
    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    @Basic
    @Column(name = "birthday", nullable = true)
    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    @Basic
    @Column(name = "enabled", nullable = false)
    public byte getEnabled() {
        return enabled;
    }

    public void setEnabled(byte enabled) {
        this.enabled = enabled;
    }

    @Basic
    @Column(name = "salt", nullable = false, length = 255)
    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    @Basic
    @Column(name = "password", nullable = false, length = 255)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Basic
    @Column(name = "confirmation_token", nullable = true, length = 255)
    public String getConfirmationToken() {
        return confirmationToken;
    }

    public void setConfirmationToken(String confirmationToken) {
        this.confirmationToken = confirmationToken;
    }

    @Basic
    @Column(name = "password_requested", nullable = true)
    public Timestamp getPasswordRequested() {
        return passwordRequested;
    }

    public void setPasswordRequested(Timestamp passwordRequested) {
        this.passwordRequested = passwordRequested;
    }

    @Basic
    @Column(name = "last_login", nullable = true)
    public Timestamp getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(Timestamp lastLogin) {
        this.lastLogin = lastLogin;
    }

    @Basic
    @Column(name = "login_count", nullable = false)
    public int getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(int loginCount) {
        this.loginCount = loginCount;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "title", nullable = true, length = 255)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "password_changed", nullable = true)
    public Timestamp getPasswordChanged() {
        return passwordChanged;
    }

    public void setPasswordChanged(Timestamp passwordChanged) {
        this.passwordChanged = passwordChanged;
    }

    @Basic
    @Column(name = "googleid", nullable = true, length = 255)
    public String getGoogleId() {
        return googleId;
    }

    public void setGoogleId(String googleId) {
        this.googleId = googleId;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OroUser oroUser = (OroUser) o;

        if (id != oroUser.id) return false;
        if (enabled != oroUser.enabled) return false;
        if (loginCount != oroUser.loginCount) return false;
        if (businessUnitOwnerId != null ? !businessUnitOwnerId.equals(oroUser.businessUnitOwnerId) : oroUser.businessUnitOwnerId != null)
            return false;
        if (username != null ? !username.equals(oroUser.username) : oroUser.username != null) return false;
        if (email != null ? !email.equals(oroUser.email) : oroUser.email != null) return false;
        if (phone != null ? !phone.equals(oroUser.phone) : oroUser.phone != null) return false;
        if (namePrefix != null ? !namePrefix.equals(oroUser.namePrefix) : oroUser.namePrefix != null) return false;
        if (firstName != null ? !firstName.equals(oroUser.firstName) : oroUser.firstName != null) return false;
        if (middleName != null ? !middleName.equals(oroUser.middleName) : oroUser.middleName != null) return false;
        if (lastName != null ? !lastName.equals(oroUser.lastName) : oroUser.lastName != null) return false;
        if (nameSuffix != null ? !nameSuffix.equals(oroUser.nameSuffix) : oroUser.nameSuffix != null) return false;
        if (birthday != null ? !birthday.equals(oroUser.birthday) : oroUser.birthday != null) return false;
        if (salt != null ? !salt.equals(oroUser.salt) : oroUser.salt != null) return false;
        if (password != null ? !password.equals(oroUser.password) : oroUser.password != null) return false;
        if (confirmationToken != null ? !confirmationToken.equals(oroUser.confirmationToken) : oroUser.confirmationToken != null)
            return false;
        if (passwordRequested != null ? !passwordRequested.equals(oroUser.passwordRequested) : oroUser.passwordRequested != null)
            return false;
        if (lastLogin != null ? !lastLogin.equals(oroUser.lastLogin) : oroUser.lastLogin != null) return false;
        if (createdAt != null ? !createdAt.equals(oroUser.createdAt) : oroUser.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(oroUser.updatedAt) : oroUser.updatedAt != null) return false;
        if (title != null ? !title.equals(oroUser.title) : oroUser.title != null) return false;
        if (passwordChanged != null ? !passwordChanged.equals(oroUser.passwordChanged) : oroUser.passwordChanged != null)
            return false;
        if (googleId != null ? !googleId.equals(oroUser.googleId) : oroUser.googleId != null) return false;
        if (serializedData != null ? !serializedData.equals(oroUser.serializedData) : oroUser.serializedData != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (businessUnitOwnerId != null ? businessUnitOwnerId.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (namePrefix != null ? namePrefix.hashCode() : 0);
        result = 31 * result + (firstName != null ? firstName.hashCode() : 0);
        result = 31 * result + (middleName != null ? middleName.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (nameSuffix != null ? nameSuffix.hashCode() : 0);
        result = 31 * result + (birthday != null ? birthday.hashCode() : 0);
        result = 31 * result + (int) enabled;
        result = 31 * result + (salt != null ? salt.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (confirmationToken != null ? confirmationToken.hashCode() : 0);
        result = 31 * result + (passwordRequested != null ? passwordRequested.hashCode() : 0);
        result = 31 * result + (lastLogin != null ? lastLogin.hashCode() : 0);
        result = 31 * result + loginCount;
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (passwordChanged != null ? passwordChanged.hashCode() : 0);
        result = 31 * result + (googleId != null ? googleId.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        return result;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByUserId")
    public Collection<NfqEmployee> getNfqEmployeesById() {
        return nfqEmployeesById;
    }

    public void setNfqEmployeesById(Collection<NfqEmployee> nfqEmployeesById) {
        this.nfqEmployeesById = nfqEmployeesById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByAssigneeId")
    public Collection<NfqTask> getNfqTasksById() {
        return nfqTasksById;
    }

    public void setNfqTasksById(Collection<NfqTask> nfqTasksById) {
        this.nfqTasksById = nfqTasksById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByAuthorId")
    public Collection<NfqTask> getNfqTasksById_0() {
        return nfqTasksById_0;
    }

    public void setNfqTasksById_0(Collection<NfqTask> nfqTasksById_0) {
        this.nfqTasksById_0 = nfqTasksById_0;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByOwnerId")
    public Collection<NfqTaskMaterial> getNfqTaskMaterialsById() {
        return nfqTaskMaterialsById;
    }

    public void setNfqTaskMaterialsById(Collection<NfqTaskMaterial> nfqTaskMaterialsById) {
        this.nfqTaskMaterialsById = nfqTaskMaterialsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByUpdatedById")
    public Collection<NfqTaskMaterial> getNfqTaskMaterialsById_0() {
        return nfqTaskMaterialsById_0;
    }

    public void setNfqTaskMaterialsById_0(Collection<NfqTaskMaterial> nfqTaskMaterialsById_0) {
        this.nfqTaskMaterialsById_0 = nfqTaskMaterialsById_0;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByAssigneeId")
    public Collection<NfqTicket> getNfqTicketsById() {
        return nfqTicketsById;
    }

    public void setNfqTicketsById(Collection<NfqTicket> nfqTicketsById) {
        this.nfqTicketsById = nfqTicketsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserBySupervisorId")
    public Collection<NfqTicket> getNfqTicketsById_0() {
        return nfqTicketsById_0;
    }

    public void setNfqTicketsById_0(Collection<NfqTicket> nfqTicketsById_0) {
        this.nfqTicketsById_0 = nfqTicketsById_0;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByWorkManagerId")
    public Collection<NfqTicket> getNfqTicketsById_1() {
        return nfqTicketsById_1;
    }

    public void setNfqTicketsById_1(Collection<NfqTicket> nfqTicketsById_1) {
        this.nfqTicketsById_1 = nfqTicketsById_1;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "oroUserByAuthorId")
    public Collection<NfqTicket> getNfqTicketsById_2() {
        return nfqTicketsById_2;
    }

    public void setNfqTicketsById_2(Collection<NfqTicket> nfqTicketsById_2) {
        this.nfqTicketsById_2 = nfqTicketsById_2;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_unit_owner_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroBusinessUnit getOroBusinessUnitByBusinessUnitOwnerId() {
        return oroBusinessUnitByBusinessUnitOwnerId;
    }

    public void setOroBusinessUnitByBusinessUnitOwnerId(OroBusinessUnit oroBusinessUnitByBusinessUnitOwnerId) {
        this.oroBusinessUnitByBusinessUnitOwnerId = oroBusinessUnitByBusinessUnitOwnerId;
    }
}
