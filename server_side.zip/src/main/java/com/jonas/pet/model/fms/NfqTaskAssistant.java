package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "nfq_task_assistant", schema = "platform", indexes = {
        @Index(name = "IDX_8A3B38F28C03F15C", columnList = "employee_id", unique = false),
        @Index(name = "IDX_8A3B38F28DB60186", columnList = "task_id", unique = false)
})
@IdClass(NfqTaskAssistantPK.class)
public class NfqTaskAssistant {
    @JsonIgnore
    private int taskId;
    private int employeeId;
    private NfqTask nfqTaskByTaskId;
    private NfqEmployee nfqEmployeeByEmployeeId;

    @Id
    @Column(name = "task_id", nullable = false)
    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    @Id
    @Column(name = "employee_id", nullable = false)
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqTaskAssistant that = (NfqTaskAssistant) o;

        if (taskId != that.taskId) return false;
        if (employeeId != that.employeeId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = taskId;
        result = 31 * result + employeeId;
        return result;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", referencedColumnName = "id", nullable = false, insertable=false, updatable=false)
    public NfqTask getNfqTaskByTaskId() {
        return nfqTaskByTaskId;
    }

    public void setNfqTaskByTaskId(NfqTask nfqTaskByTaskId) {
        this.nfqTaskByTaskId = nfqTaskByTaskId;
    }


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", referencedColumnName = "id", nullable = false, insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByEmployeeId() {
        return nfqEmployeeByEmployeeId;
    }

    public void setNfqEmployeeByEmployeeId(NfqEmployee nfqEmployeeByEmployeeId) {
        this.nfqEmployeeByEmployeeId = nfqEmployeeByEmployeeId;
    }
}
