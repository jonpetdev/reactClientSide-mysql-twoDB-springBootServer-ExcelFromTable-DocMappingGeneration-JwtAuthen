package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "nfq_material_task_material", schema = "platform", indexes = {
        @Index(name = "IDX_2E692CA28DB60186", columnList = "task_id", unique = false),
        @Index(name = "IDX_2E692CA2E308AC6F", columnList = "material_id", unique = false)
})
public class NfqMaterialTaskMaterial {
    @JsonIgnore
    private int id;
    @JsonIgnore
    private int materialId;
    @JsonIgnore
    private int taskId;

    private String measurementUnit;
    private double quantity;
    private double price;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    
    private NfqMaterial nfqMaterialByMaterialId;
    private NfqTask nfqTaskByTaskId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "material_id", nullable = false)
    public int getMaterialId() {
        return materialId;
    }

    public void setMaterialId(int materialId) {
        this.materialId = materialId;
    }

    @Basic
    @Column(name = "task_id", nullable = false)
    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    @Basic
    @Column(name = "measurement_unit", nullable = false, length = 255)
    public String getMeasurementUnit() {
        return measurementUnit;
    }

    public void setMeasurementUnit(String measurementUnit) {
        this.measurementUnit = measurementUnit;
    }

    @Basic
    @Column(name = "quantity", nullable = false, precision = 0)
    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    @Basic
    @Column(name = "price", nullable = false, precision = 0)
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqMaterialTaskMaterial that = (NfqMaterialTaskMaterial) o;

        if (id != that.id) return false;
        if (materialId != that.materialId) return false;
        if (taskId != that.taskId) return false;
        if (Double.compare(that.quantity, quantity) != 0) return false;
        if (Double.compare(that.price, price) != 0) return false;
        if (measurementUnit != null ? !measurementUnit.equals(that.measurementUnit) : that.measurementUnit != null)
            return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(that.updatedAt) : that.updatedAt != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + materialId;
        result = 31 * result + taskId;
        result = 31 * result + (measurementUnit != null ? measurementUnit.hashCode() : 0);
        temp = Double.doubleToLongBits(quantity);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(price);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "material_id", referencedColumnName = "id", nullable = false, insertable=false, updatable=false)
    public NfqMaterial getNfqMaterialByMaterialId() {
        return nfqMaterialByMaterialId;
    }

    public void setNfqMaterialByMaterialId(NfqMaterial nfqMaterialByMaterialId) {
        this.nfqMaterialByMaterialId = nfqMaterialByMaterialId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", referencedColumnName = "id", nullable = false, insertable=false, updatable=false)
    public NfqTask getNfqTaskByTaskId() {
        return nfqTaskByTaskId;
    }

    public void setNfqTaskByTaskId(NfqTask nfqTaskByTaskId) {
        this.nfqTaskByTaskId = nfqTaskByTaskId;
    }
}
