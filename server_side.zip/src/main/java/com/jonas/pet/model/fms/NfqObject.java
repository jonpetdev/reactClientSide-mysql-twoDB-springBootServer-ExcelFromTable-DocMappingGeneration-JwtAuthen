package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "nfq_object", schema = "platform", catalog = "")
public class NfqObject {

    private int id;
    @JsonIgnore
    private Integer businessUnitId;
    @JsonIgnore
    private Integer houseId;
    @JsonIgnore
    private String uuid;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    @JsonIgnore
    private Timestamp maintenanceValidTill;
    @JsonIgnore
    private byte active;

    private Integer externalId;
    @JsonIgnore
    private String number;
    @JsonIgnore
    private byte isHouse;

    private String city;
    private String street;
    private Integer houseNumber;
    private String houseLetter;
    private String pavilion;
    private String flatNumber;
    @JsonIgnore
    private String zipCode;

    private BigDecimal area;
    @JsonIgnore
    private String note;
    @JsonIgnore
    private String commissioner;
    @JsonIgnore
    private String heatEconomySupervisor;

    private int floorCount;
    @JsonIgnore
    private int staircaseCount;
    @JsonIgnore
    private String doorCodes;
    @JsonIgnore
    private Byte heatPoint;

    private Integer floorNumber;

    private Integer constructionYear;
    @JsonIgnore
    private String renovationInfo;
    @JsonIgnore
    private BigDecimal balance;
    @JsonIgnore
    private BigDecimal accumulatedFundsDebt;
    @JsonIgnore
    private BigDecimal accumulatedFundsUnused;
    @JsonIgnore
    private BigDecimal elevatorFundsDebt;
    @JsonIgnore
    private BigDecimal elevatorFundsUnused;
    @JsonIgnore
    private String cadastralNumber;
    @JsonIgnore
    private String ownershipForm;
    @JsonIgnore
    private String purpose;
    @JsonIgnore
    private String system;
    @JsonIgnore
    private String technicalSupervisor;
    @JsonIgnore
    private String corpus;
    @JsonIgnore
    private String billingServices;
    @JsonIgnore
    private Integer assistantId;
    @JsonIgnore
    private Integer headManagerId;
    @JsonIgnore
    private Integer dateOfBilling;



    private OroBusinessUnit oroBusinessUnitByBusinessUnitId;
    private NfqObject nfqObjectByHouseId;
    private Collection<NfqObject> nfqObjectsById;
    private NfqEmployee nfqEmployeeByTechnicalManagerId;
    private NfqEmployee nfqEmployeeByAssistantId;
    private NfqEmployee nfqEmployeeByHeadManagerId;
    private NfqEmployee nfqEmployeeByAccountantId;
    private NfqEmployee nfqEmployeeByLawyerId;
    private Collection<NfqTicket> nfqTicketsById;

    @JsonIgnore
    private Integer statusId;

    private Integer typeId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "business_unit_id", nullable = true)
    public Integer getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(Integer businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    @Basic
    @Column(name = "house_id", nullable = true)
    public Integer getHouseId() {
        return houseId;
    }

    public void setHouseId(Integer houseId) {
        this.houseId = houseId;
    }

    @Basic
    @Column(name = "uuid", nullable = false, length = 36)
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "maintenance_valid_till", nullable = true)
    public Timestamp getMaintenanceValidTill() {
        return maintenanceValidTill;
    }

    public void setMaintenanceValidTill(Timestamp maintenanceValidTill) {
        this.maintenanceValidTill = maintenanceValidTill;
    }

    @Basic
    @Column(name = "active", nullable = false)
    public byte getActive() {
        return active;
    }

    public void setActive(byte active) {
        this.active = active;
    }

    @Basic
    @Column(name = "external_id", nullable = true)
    public Integer getExternalId() {
        return externalId;
    }

    public void setExternalId(Integer externalId) {
        this.externalId = externalId;
    }

    @Basic
    @Column(name = "number", nullable = true, length = 255)
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Basic
    @Column(name = "is_house", nullable = false)
    public byte getIsHouse() {
        return isHouse;
    }

    public void setIsHouse(byte isHouse) {
        this.isHouse = isHouse;
    }

    @Basic
    @Column(name = "city", nullable = true, length = 255)
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Basic
    @Column(name = "street", nullable = true, length = 255)
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    @Basic
    @Column(name = "house_number", nullable = true)
    public Integer getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(Integer houseNumber) {
        this.houseNumber = houseNumber;
    }

    @Basic
    @Column(name = "house_letter", nullable = true, length = 3)
    public String getHouseLetter() {
        return houseLetter;
    }

    public void setHouseLetter(String houseLetter) {
        this.houseLetter = houseLetter;
    }

    @Basic
    @Column(name = "pavilion", nullable = true, length = 50)
    public String getPavilion() {
        return pavilion;
    }

    public void setPavilion(String pavilion) {
        this.pavilion = pavilion;
    }

    @Basic
    @Column(name = "flat_number", nullable = true, length = 50)
    public String getFlatNumber() {
        return flatNumber;
    }

    public void setFlatNumber(String flatNumber) {
        this.flatNumber = flatNumber;
    }

    @Basic
    @Column(name = "zip_code", nullable = true, length = 50)
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @Basic
    @Column(name = "area", nullable = true, precision = 2)
    public BigDecimal getArea() {
        return area;
    }

    public void setArea(BigDecimal area) {
        this.area = area;
    }

    @Basic
    @Column(name = "note", nullable = true, length = -1)
    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Basic
    @Column(name = "commissioner", nullable = true, length = 255)
    public String getCommissioner() {
        return commissioner;
    }

    public void setCommissioner(String commissioner) {
        this.commissioner = commissioner;
    }

    @Basic
    @Column(name = "heat_economy_supervisor", nullable = true, length = 255)
    public String getHeatEconomySupervisor() {
        return heatEconomySupervisor;
    }

    public void setHeatEconomySupervisor(String heatEconomySupervisor) {
        this.heatEconomySupervisor = heatEconomySupervisor;
    }

    @Basic
    @Column(name = "floor_count", nullable = false)
    public int getFloorCount() {
        return floorCount;
    }

    public void setFloorCount(int floorCount) {
        this.floorCount = floorCount;
    }

    @Basic
    @Column(name = "staircase_count", nullable = false)
    public int getStaircaseCount() {
        return staircaseCount;
    }

    public void setStaircaseCount(int staircaseCount) {
        this.staircaseCount = staircaseCount;
    }

    @Basic
    @Column(name = "door_codes", nullable = true, length = 255)
    public String getDoorCodes() {
        return doorCodes;
    }

    public void setDoorCodes(String doorCodes) {
        this.doorCodes = doorCodes;
    }

    @Basic
    @Column(name = "heat_point", nullable = true)
    public Byte getHeatPoint() {
        return heatPoint;
    }

    public void setHeatPoint(Byte heatPoint) {
        this.heatPoint = heatPoint;
    }

    @Basic
    @Column(name = "floor_number", nullable = true)
    public Integer getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(Integer floorNumber) {
        this.floorNumber = floorNumber;
    }

    @Basic
    @Column(name = "construction_year", nullable = true)
    public Integer getConstructionYear() {
        return constructionYear;
    }

    public void setConstructionYear(Integer constructionYear) {
        this.constructionYear = constructionYear;
    }

    @Basic
    @Column(name = "renovation_info", nullable = true, length = -1)
    public String getRenovationInfo() {
        return renovationInfo;
    }

    public void setRenovationInfo(String renovationInfo) {
        this.renovationInfo = renovationInfo;
    }

    @Basic
    @Column(name = "balance", nullable = false, precision = 2)
    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    @Basic
    @Column(name = "accumulated_funds_debt", nullable = false, precision = 2)
    public BigDecimal getAccumulatedFundsDebt() {
        return accumulatedFundsDebt;
    }

    public void setAccumulatedFundsDebt(BigDecimal accumulatedFundsDebt) {
        this.accumulatedFundsDebt = accumulatedFundsDebt;
    }

    @Basic
    @Column(name = "accumulated_funds_unused", nullable = false, precision = 2)
    public BigDecimal getAccumulatedFundsUnused() {
        return accumulatedFundsUnused;
    }

    public void setAccumulatedFundsUnused(BigDecimal accumulatedFundsUnused) {
        this.accumulatedFundsUnused = accumulatedFundsUnused;
    }

    @Basic
    @Column(name = "elevator_funds_debt", nullable = false, precision = 2)
    public BigDecimal getElevatorFundsDebt() {
        return elevatorFundsDebt;
    }

    public void setElevatorFundsDebt(BigDecimal elevatorFundsDebt) {
        this.elevatorFundsDebt = elevatorFundsDebt;
    }

    @Basic
    @Column(name = "elevator_funds_unused", nullable = false, precision = 2)
    public BigDecimal getElevatorFundsUnused() {
        return elevatorFundsUnused;
    }

    public void setElevatorFundsUnused(BigDecimal elevatorFundsUnused) {
        this.elevatorFundsUnused = elevatorFundsUnused;
    }

    @Basic
    @Column(name = "cadastral_number", nullable = true, length = 255)
    public String getCadastralNumber() {
        return cadastralNumber;
    }

    public void setCadastralNumber(String cadastralNumber) {
        this.cadastralNumber = cadastralNumber;
    }

    @Basic
    @Column(name = "ownership_form", nullable = true, length = 32)
    public String getOwnershipForm() {
        return ownershipForm;
    }

    public void setOwnershipForm(String ownershipForm) {
        this.ownershipForm = ownershipForm;
    }

    @Basic
    @Column(name = "purpose", nullable = true, length = 32)
    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    @Basic
    @Column(name = "system", nullable = false, length = 255)
    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    @Basic
    @Column(name = "technical_supervisor", nullable = true, length = 255)
    public String getTechnicalSupervisor() {
        return technicalSupervisor;
    }

    public void setTechnicalSupervisor(String technicalSupervisor) {
        this.technicalSupervisor = technicalSupervisor;
    }

    @Basic
    @Column(name = "corpus", nullable = true, length = 255)
    public String getCorpus() {
        return corpus;
    }

    public void setCorpus(String corpus) {
        this.corpus = corpus;
    }

    @Basic
    @Column(name = "billing_services", nullable = true, length = -1)
    public String getBillingServices() {
        return billingServices;
    }

    public void setBillingServices(String billingServices) {
        this.billingServices = billingServices;
    }

    @Basic
    @Column(name = "assistant_id", nullable = true)
    public Integer getAssistantId() {
        return assistantId;
    }

    public void setAssistantId(Integer assistantId) {
        this.assistantId = assistantId;
    }

    @Basic
    @Column(name = "head_manager_id", nullable = true)
    public Integer getHeadManagerId() {
        return headManagerId;
    }

    public void setHeadManagerId(Integer headManagerId) {
        this.headManagerId = headManagerId;
    }

    @Basic
    @Column(name = "date_of_billing", nullable = true)
    public Integer getDateOfBilling() {
        return dateOfBilling;
    }

    public void setDateOfBilling(Integer dateOfBilling) {
        this.dateOfBilling = dateOfBilling;
    }

    @Basic
    @Column(name = "status_id", nullable = true)
    public Integer getStatusId() {
        return statusId;
    }

    public void setStatusId(Integer statusId) {
        this.statusId = statusId;
    }

    @Basic
    @Column(name = "type_id", nullable = true)
    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqObject nfqObject = (NfqObject) o;

        if (id != nfqObject.id) return false;
        if (active != nfqObject.active) return false;
        if (isHouse != nfqObject.isHouse) return false;
        if (floorCount != nfqObject.floorCount) return false;
        if (staircaseCount != nfqObject.staircaseCount) return false;
        if (businessUnitId != null ? !businessUnitId.equals(nfqObject.businessUnitId) : nfqObject.businessUnitId != null)
            return false;
        if (houseId != null ? !houseId.equals(nfqObject.houseId) : nfqObject.houseId != null) return false;
        if (uuid != null ? !uuid.equals(nfqObject.uuid) : nfqObject.uuid != null) return false;
        if (createdAt != null ? !createdAt.equals(nfqObject.createdAt) : nfqObject.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(nfqObject.updatedAt) : nfqObject.updatedAt != null) return false;
        if (maintenanceValidTill != null ? !maintenanceValidTill.equals(nfqObject.maintenanceValidTill) : nfqObject.maintenanceValidTill != null)
            return false;
        if (externalId != null ? !externalId.equals(nfqObject.externalId) : nfqObject.externalId != null) return false;
        if (number != null ? !number.equals(nfqObject.number) : nfqObject.number != null) return false;
        if (city != null ? !city.equals(nfqObject.city) : nfqObject.city != null) return false;
        if (street != null ? !street.equals(nfqObject.street) : nfqObject.street != null) return false;
        if (houseNumber != null ? !houseNumber.equals(nfqObject.houseNumber) : nfqObject.houseNumber != null)
            return false;
        if (houseLetter != null ? !houseLetter.equals(nfqObject.houseLetter) : nfqObject.houseLetter != null)
            return false;
        if (pavilion != null ? !pavilion.equals(nfqObject.pavilion) : nfqObject.pavilion != null) return false;
        if (flatNumber != null ? !flatNumber.equals(nfqObject.flatNumber) : nfqObject.flatNumber != null) return false;
        if (zipCode != null ? !zipCode.equals(nfqObject.zipCode) : nfqObject.zipCode != null) return false;
        if (area != null ? !area.equals(nfqObject.area) : nfqObject.area != null) return false;
        if (note != null ? !note.equals(nfqObject.note) : nfqObject.note != null) return false;
        if (commissioner != null ? !commissioner.equals(nfqObject.commissioner) : nfqObject.commissioner != null)
            return false;
        if (heatEconomySupervisor != null ? !heatEconomySupervisor.equals(nfqObject.heatEconomySupervisor) : nfqObject.heatEconomySupervisor != null)
            return false;
        if (doorCodes != null ? !doorCodes.equals(nfqObject.doorCodes) : nfqObject.doorCodes != null) return false;
        if (heatPoint != null ? !heatPoint.equals(nfqObject.heatPoint) : nfqObject.heatPoint != null) return false;
        if (floorNumber != null ? !floorNumber.equals(nfqObject.floorNumber) : nfqObject.floorNumber != null)
            return false;
        if (constructionYear != null ? !constructionYear.equals(nfqObject.constructionYear) : nfqObject.constructionYear != null)
            return false;
        if (renovationInfo != null ? !renovationInfo.equals(nfqObject.renovationInfo) : nfqObject.renovationInfo != null)
            return false;
        if (balance != null ? !balance.equals(nfqObject.balance) : nfqObject.balance != null) return false;
        if (accumulatedFundsDebt != null ? !accumulatedFundsDebt.equals(nfqObject.accumulatedFundsDebt) : nfqObject.accumulatedFundsDebt != null)
            return false;
        if (accumulatedFundsUnused != null ? !accumulatedFundsUnused.equals(nfqObject.accumulatedFundsUnused) : nfqObject.accumulatedFundsUnused != null)
            return false;
        if (elevatorFundsDebt != null ? !elevatorFundsDebt.equals(nfqObject.elevatorFundsDebt) : nfqObject.elevatorFundsDebt != null)
            return false;
        if (elevatorFundsUnused != null ? !elevatorFundsUnused.equals(nfqObject.elevatorFundsUnused) : nfqObject.elevatorFundsUnused != null)
            return false;
        if (cadastralNumber != null ? !cadastralNumber.equals(nfqObject.cadastralNumber) : nfqObject.cadastralNumber != null)
            return false;
        if (ownershipForm != null ? !ownershipForm.equals(nfqObject.ownershipForm) : nfqObject.ownershipForm != null)
            return false;
        if (purpose != null ? !purpose.equals(nfqObject.purpose) : nfqObject.purpose != null) return false;
        if (system != null ? !system.equals(nfqObject.system) : nfqObject.system != null) return false;
        if (technicalSupervisor != null ? !technicalSupervisor.equals(nfqObject.technicalSupervisor) : nfqObject.technicalSupervisor != null)
            return false;
        if (corpus != null ? !corpus.equals(nfqObject.corpus) : nfqObject.corpus != null) return false;
        if (billingServices != null ? !billingServices.equals(nfqObject.billingServices) : nfqObject.billingServices != null)
            return false;
        if (assistantId != null ? !assistantId.equals(nfqObject.assistantId) : nfqObject.assistantId != null)
            return false;
        if (headManagerId != null ? !headManagerId.equals(nfqObject.headManagerId) : nfqObject.headManagerId != null)
            return false;
        if (dateOfBilling != null ? !dateOfBilling.equals(nfqObject.dateOfBilling) : nfqObject.dateOfBilling != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (businessUnitId != null ? businessUnitId.hashCode() : 0);
        result = 31 * result + (houseId != null ? houseId.hashCode() : 0);
        result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (maintenanceValidTill != null ? maintenanceValidTill.hashCode() : 0);
        result = 31 * result + (int) active;
        result = 31 * result + (externalId != null ? externalId.hashCode() : 0);
        result = 31 * result + (number != null ? number.hashCode() : 0);
        result = 31 * result + (int) isHouse;
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (street != null ? street.hashCode() : 0);
        result = 31 * result + (houseNumber != null ? houseNumber.hashCode() : 0);
        result = 31 * result + (houseLetter != null ? houseLetter.hashCode() : 0);
        result = 31 * result + (pavilion != null ? pavilion.hashCode() : 0);
        result = 31 * result + (flatNumber != null ? flatNumber.hashCode() : 0);
        result = 31 * result + (zipCode != null ? zipCode.hashCode() : 0);
        result = 31 * result + (area != null ? area.hashCode() : 0);
        result = 31 * result + (note != null ? note.hashCode() : 0);
        result = 31 * result + (commissioner != null ? commissioner.hashCode() : 0);
        result = 31 * result + (heatEconomySupervisor != null ? heatEconomySupervisor.hashCode() : 0);
        result = 31 * result + floorCount;
        result = 31 * result + staircaseCount;
        result = 31 * result + (doorCodes != null ? doorCodes.hashCode() : 0);
        result = 31 * result + (heatPoint != null ? heatPoint.hashCode() : 0);
        result = 31 * result + (floorNumber != null ? floorNumber.hashCode() : 0);
        result = 31 * result + (constructionYear != null ? constructionYear.hashCode() : 0);
        result = 31 * result + (renovationInfo != null ? renovationInfo.hashCode() : 0);
        result = 31 * result + (balance != null ? balance.hashCode() : 0);
        result = 31 * result + (accumulatedFundsDebt != null ? accumulatedFundsDebt.hashCode() : 0);
        result = 31 * result + (accumulatedFundsUnused != null ? accumulatedFundsUnused.hashCode() : 0);
        result = 31 * result + (elevatorFundsDebt != null ? elevatorFundsDebt.hashCode() : 0);
        result = 31 * result + (elevatorFundsUnused != null ? elevatorFundsUnused.hashCode() : 0);
        result = 31 * result + (cadastralNumber != null ? cadastralNumber.hashCode() : 0);
        result = 31 * result + (ownershipForm != null ? ownershipForm.hashCode() : 0);
        result = 31 * result + (purpose != null ? purpose.hashCode() : 0);
        result = 31 * result + (system != null ? system.hashCode() : 0);
        result = 31 * result + (technicalSupervisor != null ? technicalSupervisor.hashCode() : 0);
        result = 31 * result + (corpus != null ? corpus.hashCode() : 0);
        result = 31 * result + (billingServices != null ? billingServices.hashCode() : 0);
        result = 31 * result + (assistantId != null ? assistantId.hashCode() : 0);
        result = 31 * result + (headManagerId != null ? headManagerId.hashCode() : 0);
        result = 31 * result + (dateOfBilling != null ? dateOfBilling.hashCode() : 0);
        return result;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_unit_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroBusinessUnit getOroBusinessUnitByBusinessUnitId() {
        return oroBusinessUnitByBusinessUnitId;
    }

    public void setOroBusinessUnitByBusinessUnitId(OroBusinessUnit oroBusinessUnitByBusinessUnitId) {
        this.oroBusinessUnitByBusinessUnitId = oroBusinessUnitByBusinessUnitId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "house_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqObject getNfqObjectByHouseId() {
        return nfqObjectByHouseId;
    }

    public void setNfqObjectByHouseId(NfqObject nfqObjectByHouseId) {
        this.nfqObjectByHouseId = nfqObjectByHouseId;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqObjectByHouseId")
    public Collection<NfqObject> getNfqObjectsById() {
        return nfqObjectsById;
    }

    public void setNfqObjectsById(Collection<NfqObject> nfqObjectsById) {
        this.nfqObjectsById = nfqObjectsById;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "technical_manager_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByTechnicalManagerId() {
        return nfqEmployeeByTechnicalManagerId;
    }

    public void setNfqEmployeeByTechnicalManagerId(NfqEmployee nfqEmployeeByTechnicalManagerId) {
        this.nfqEmployeeByTechnicalManagerId = nfqEmployeeByTechnicalManagerId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assistant_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByAssistantId() {
        return nfqEmployeeByAssistantId;
    }

    public void setNfqEmployeeByAssistantId(NfqEmployee nfqEmployeeByAssistantId) {
        this.nfqEmployeeByAssistantId = nfqEmployeeByAssistantId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "head_manager_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByHeadManagerId() {
        return nfqEmployeeByHeadManagerId;
    }

    public void setNfqEmployeeByHeadManagerId(NfqEmployee nfqEmployeeByHeadManagerId) {
        this.nfqEmployeeByHeadManagerId = nfqEmployeeByHeadManagerId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "accountant_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByAccountantId() {
        return nfqEmployeeByAccountantId;
    }

    public void setNfqEmployeeByAccountantId(NfqEmployee nfqEmployeeByAccountantId) {
        this.nfqEmployeeByAccountantId = nfqEmployeeByAccountantId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lawyer_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqEmployee getNfqEmployeeByLawyerId() {
        return nfqEmployeeByLawyerId;
    }

    public void setNfqEmployeeByLawyerId(NfqEmployee nfqEmployeeByLawyerId) {
        this.nfqEmployeeByLawyerId = nfqEmployeeByLawyerId;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqObjectByObjectId")
    public Collection<NfqTicket> getNfqTicketsById() {
        return nfqTicketsById;
    }

    public void setNfqTicketsById(Collection<NfqTicket> nfqTicketsById) {
        this.nfqTicketsById = nfqTicketsById;
    }
}
