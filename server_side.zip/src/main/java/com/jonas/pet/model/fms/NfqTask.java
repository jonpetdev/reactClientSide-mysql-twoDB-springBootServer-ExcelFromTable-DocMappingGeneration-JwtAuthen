package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "nfq_task", schema = "platform", indexes = {
        @Index(name = "IDX_4122967859EC7D60", columnList = "assignee_id", unique = false),
        @Index(name = "IDX_41229678700047D2", columnList = "ticket_id", unique = false),
        @Index(name = "IDX_41229678F107E7C6", columnList = "last_status", unique = false)
})
public class NfqTask {
    private int id;
    @JsonIgnore
    private Integer assigneeId;
    @JsonIgnore
    private Integer businessUnitId;
    @JsonIgnore
    private Integer ticketId;
    @JsonIgnore
    private byte isActive;
    @JsonIgnore
    private String uuid;

    private String title;

    private String lastStatus;
    @JsonIgnore
    private Timestamp dateToStart;
    @JsonIgnore
    private Timestamp deadline;

    private String description;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;

    private int workDuration;
    @JsonIgnore
    private String signatoryFirstName;
    @JsonIgnore
    private String signatoryLastName;
    @JsonIgnore
    private String serializedData;
    @JsonIgnore
    private Timestamp startTime;

    private Timestamp finishTime;
    @JsonIgnore
    private byte automatic;
    @JsonIgnore
    private String workComments;

    private String taskType;
    @JsonIgnore
    private String emergencyWorkActNumber;
    @JsonIgnore
    private int stopCount;
    @JsonIgnore
    private String inspectionActNumber;
    @JsonIgnore
    private Timestamp inspectionActGeneratedAt;
    @JsonIgnore
    private String ltInitialFlowCategory;
    @JsonIgnore
    private String comments;
    @JsonIgnore
    private String materials;
    @JsonIgnore
    private Integer authorId;
    @JsonIgnore
    private byte workCommentRequired;
    @JsonIgnore
    private Timestamp emergencyWorkactGeneratedAt;
    @JsonIgnore
    private Date deliveryActDate;
    
    private Collection<NfqMaterialTaskMaterial> nfqMaterialTaskMaterialsById;
    private OroUser oroUserByAssigneeId;
    private OroBusinessUnit oroBusinessUnitByBusinessUnitId;
    private NfqTicket nfqTicketByTicketId;
    private OroUser oroUserByAuthorId;
    private Collection<NfqTaskAssistant> nfqTaskAssistantsById;
    private Collection<NfqTaskMaterial> nfqTaskMaterialsById;
    private Collection<NfqTicket> nfqTicketsById;
    private Collection<NfqTicket> nfqTicketsById_0;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "assignee_id", nullable = true)
    public Integer getAssigneeId() {
        return assigneeId;
    }

    public void setAssigneeId(Integer assigneeId) {
        this.assigneeId = assigneeId;
    }

    @Basic
    @Column(name = "business_unit_id", nullable = true)
    public Integer getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(Integer businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    @Basic
    @Column(name = "ticket_id", nullable = true)
    public Integer getTicketId() {
        return ticketId;
    }

    public void setTicketId(Integer ticketId) {
        this.ticketId = ticketId;
    }

    @Basic
    @Column(name = "is_active", nullable = false)
    public byte getIsActive() {
        return isActive;
    }

    public void setIsActive(byte isActive) {
        this.isActive = isActive;
    }

    @Basic
    @Column(name = "uuid", nullable = false, length = 36)
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Basic
    @Column(name = "title", nullable = false, length = 255)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "last_status", nullable = false, length = 255)
    public String getLastStatus() {
        return lastStatus;
    }

    public void setLastStatus(String lastStatus) {
        this.lastStatus = lastStatus;
    }

    @Basic
    @Column(name = "date_to_start", nullable = false)
    public Timestamp getDateToStart() {
        return dateToStart;
    }

    public void setDateToStart(Timestamp dateToStart) {
        this.dateToStart = dateToStart;
    }

    @Basic
    @Column(name = "deadline", nullable = false)
    public Timestamp getDeadline() {
        return deadline;
    }

    public void setDeadline(Timestamp deadline) {
        this.deadline = deadline;
    }

    @Basic
    @Column(name = "description", nullable = false, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "work_duration", nullable = false)
    public int getWorkDuration() {
        return workDuration;
    }

    public void setWorkDuration(int workDuration) {
        this.workDuration = workDuration;
    }

    @Basic
    @Column(name = "signatory_first_name", nullable = true, length = 64)
    public String getSignatoryFirstName() {
        return signatoryFirstName;
    }

    public void setSignatoryFirstName(String signatoryFirstName) {
        this.signatoryFirstName = signatoryFirstName;
    }

    @Basic
    @Column(name = "signatory_last_name", nullable = true, length = 64)
    public String getSignatoryLastName() {
        return signatoryLastName;
    }

    public void setSignatoryLastName(String signatoryLastName) {
        this.signatoryLastName = signatoryLastName;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Basic
    @Column(name = "start_time", nullable = true)
    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    @Basic
    @Column(name = "finish_time", nullable = true)
    public Timestamp getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Timestamp finishTime) {
        this.finishTime = finishTime;
    }

    @Basic
    @Column(name = "automatic", nullable = false)
    public byte getAutomatic() {
        return automatic;
    }

    public void setAutomatic(byte automatic) {
        this.automatic = automatic;
    }

    @Basic
    @Column(name = "work_comments", nullable = true, length = -1)
    public String getWorkComments() {
        return workComments;
    }

    public void setWorkComments(String workComments) {
        this.workComments = workComments;
    }

    @Basic
    @Column(name = "task_type", nullable = true, length = 255)
    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    @Basic
    @Column(name = "emergency_work_act_number", nullable = true, length = 255)
    public String getEmergencyWorkActNumber() {
        return emergencyWorkActNumber;
    }

    public void setEmergencyWorkActNumber(String emergencyWorkActNumber) {
        this.emergencyWorkActNumber = emergencyWorkActNumber;
    }

    @Basic
    @Column(name = "stop_count", nullable = false)
    public int getStopCount() {
        return stopCount;
    }

    public void setStopCount(int stopCount) {
        this.stopCount = stopCount;
    }

    @Basic
    @Column(name = "inspection_act_number", nullable = true, length = 255)
    public String getInspectionActNumber() {
        return inspectionActNumber;
    }

    public void setInspectionActNumber(String inspectionActNumber) {
        this.inspectionActNumber = inspectionActNumber;
    }

    @Basic
    @Column(name = "inspection_act_generated_at", nullable = true)
    public Timestamp getInspectionActGeneratedAt() {
        return inspectionActGeneratedAt;
    }

    public void setInspectionActGeneratedAt(Timestamp inspectionActGeneratedAt) {
        this.inspectionActGeneratedAt = inspectionActGeneratedAt;
    }

    @Basic
    @Column(name = "lt_initial_flow_category", nullable = true, length = 255)
    public String getLtInitialFlowCategory() {
        return ltInitialFlowCategory;
    }

    public void setLtInitialFlowCategory(String ltInitialFlowCategory) {
        this.ltInitialFlowCategory = ltInitialFlowCategory;
    }

    @Basic
    @Column(name = "comments", nullable = true, length = -1)
    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Basic
    @Column(name = "materials", nullable = true, length = -1)
    public String getMaterials() {
        return materials;
    }

    public void setMaterials(String materials) {
        this.materials = materials;
    }

    @Basic
    @Column(name = "author_id", nullable = true)
    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    @Basic
    @Column(name = "work_comment_required", nullable = false)
    public byte getWorkCommentRequired() {
        return workCommentRequired;
    }

    public void setWorkCommentRequired(byte workCommentRequired) {
        this.workCommentRequired = workCommentRequired;
    }

    @Basic
    @Column(name = "emergency_workact_generated_at", nullable = true)
    public Timestamp getEmergencyWorkactGeneratedAt() {
        return emergencyWorkactGeneratedAt;
    }

    public void setEmergencyWorkactGeneratedAt(Timestamp emergencyWorkactGeneratedAt) {
        this.emergencyWorkactGeneratedAt = emergencyWorkactGeneratedAt;
    }

    @Basic
    @Column(name = "delivery_act_date", nullable = true)
    public Date getDeliveryActDate() {
        return deliveryActDate;
    }

    public void setDeliveryActDate(Date deliveryActDate) {
        this.deliveryActDate = deliveryActDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqTask nfqTask = (NfqTask) o;

        if (id != nfqTask.id) return false;
        if (isActive != nfqTask.isActive) return false;
        if (workDuration != nfqTask.workDuration) return false;
        if (automatic != nfqTask.automatic) return false;
        if (stopCount != nfqTask.stopCount) return false;
        if (workCommentRequired != nfqTask.workCommentRequired) return false;
        if (assigneeId != null ? !assigneeId.equals(nfqTask.assigneeId) : nfqTask.assigneeId != null) return false;
        if (businessUnitId != null ? !businessUnitId.equals(nfqTask.businessUnitId) : nfqTask.businessUnitId != null)
            return false;
        if (ticketId != null ? !ticketId.equals(nfqTask.ticketId) : nfqTask.ticketId != null) return false;
        if (uuid != null ? !uuid.equals(nfqTask.uuid) : nfqTask.uuid != null) return false;
        if (title != null ? !title.equals(nfqTask.title) : nfqTask.title != null) return false;
        if (lastStatus != null ? !lastStatus.equals(nfqTask.lastStatus) : nfqTask.lastStatus != null) return false;
        if (dateToStart != null ? !dateToStart.equals(nfqTask.dateToStart) : nfqTask.dateToStart != null) return false;
        if (deadline != null ? !deadline.equals(nfqTask.deadline) : nfqTask.deadline != null) return false;
        if (description != null ? !description.equals(nfqTask.description) : nfqTask.description != null) return false;
        if (createdAt != null ? !createdAt.equals(nfqTask.createdAt) : nfqTask.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(nfqTask.updatedAt) : nfqTask.updatedAt != null) return false;
        if (signatoryFirstName != null ? !signatoryFirstName.equals(nfqTask.signatoryFirstName) : nfqTask.signatoryFirstName != null)
            return false;
        if (signatoryLastName != null ? !signatoryLastName.equals(nfqTask.signatoryLastName) : nfqTask.signatoryLastName != null)
            return false;
        if (serializedData != null ? !serializedData.equals(nfqTask.serializedData) : nfqTask.serializedData != null)
            return false;
        if (startTime != null ? !startTime.equals(nfqTask.startTime) : nfqTask.startTime != null) return false;
        if (finishTime != null ? !finishTime.equals(nfqTask.finishTime) : nfqTask.finishTime != null) return false;
        if (workComments != null ? !workComments.equals(nfqTask.workComments) : nfqTask.workComments != null)
            return false;
        if (taskType != null ? !taskType.equals(nfqTask.taskType) : nfqTask.taskType != null) return false;
        if (emergencyWorkActNumber != null ? !emergencyWorkActNumber.equals(nfqTask.emergencyWorkActNumber) : nfqTask.emergencyWorkActNumber != null)
            return false;
        if (inspectionActNumber != null ? !inspectionActNumber.equals(nfqTask.inspectionActNumber) : nfqTask.inspectionActNumber != null)
            return false;
        if (inspectionActGeneratedAt != null ? !inspectionActGeneratedAt.equals(nfqTask.inspectionActGeneratedAt) : nfqTask.inspectionActGeneratedAt != null)
            return false;
        if (ltInitialFlowCategory != null ? !ltInitialFlowCategory.equals(nfqTask.ltInitialFlowCategory) : nfqTask.ltInitialFlowCategory != null)
            return false;
        if (comments != null ? !comments.equals(nfqTask.comments) : nfqTask.comments != null) return false;
        if (materials != null ? !materials.equals(nfqTask.materials) : nfqTask.materials != null) return false;
        if (authorId != null ? !authorId.equals(nfqTask.authorId) : nfqTask.authorId != null) return false;
        if (emergencyWorkactGeneratedAt != null ? !emergencyWorkactGeneratedAt.equals(nfqTask.emergencyWorkactGeneratedAt) : nfqTask.emergencyWorkactGeneratedAt != null)
            return false;
        if (deliveryActDate != null ? !deliveryActDate.equals(nfqTask.deliveryActDate) : nfqTask.deliveryActDate != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (assigneeId != null ? assigneeId.hashCode() : 0);
        result = 31 * result + (businessUnitId != null ? businessUnitId.hashCode() : 0);
        result = 31 * result + (ticketId != null ? ticketId.hashCode() : 0);
        result = 31 * result + (int) isActive;
        result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (lastStatus != null ? lastStatus.hashCode() : 0);
        result = 31 * result + (dateToStart != null ? dateToStart.hashCode() : 0);
        result = 31 * result + (deadline != null ? deadline.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + workDuration;
        result = 31 * result + (signatoryFirstName != null ? signatoryFirstName.hashCode() : 0);
        result = 31 * result + (signatoryLastName != null ? signatoryLastName.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        result = 31 * result + (startTime != null ? startTime.hashCode() : 0);
        result = 31 * result + (finishTime != null ? finishTime.hashCode() : 0);
        result = 31 * result + (int) automatic;
        result = 31 * result + (workComments != null ? workComments.hashCode() : 0);
        result = 31 * result + (taskType != null ? taskType.hashCode() : 0);
        result = 31 * result + (emergencyWorkActNumber != null ? emergencyWorkActNumber.hashCode() : 0);
        result = 31 * result + stopCount;
        result = 31 * result + (inspectionActNumber != null ? inspectionActNumber.hashCode() : 0);
        result = 31 * result + (inspectionActGeneratedAt != null ? inspectionActGeneratedAt.hashCode() : 0);
        result = 31 * result + (ltInitialFlowCategory != null ? ltInitialFlowCategory.hashCode() : 0);
        result = 31 * result + (comments != null ? comments.hashCode() : 0);
        result = 31 * result + (materials != null ? materials.hashCode() : 0);
        result = 31 * result + (authorId != null ? authorId.hashCode() : 0);
        result = 31 * result + (int) workCommentRequired;
        result = 31 * result + (emergencyWorkactGeneratedAt != null ? emergencyWorkactGeneratedAt.hashCode() : 0);
        result = 31 * result + (deliveryActDate != null ? deliveryActDate.hashCode() : 0);
        return result;
    }


    @OneToMany(mappedBy = "nfqTaskByTaskId")
    public Collection<NfqMaterialTaskMaterial> getNfqMaterialTaskMaterialsById() {
        return nfqMaterialTaskMaterialsById;
    }

    public void setNfqMaterialTaskMaterialsById(Collection<NfqMaterialTaskMaterial> nfqMaterialTaskMaterialsById) {
        this.nfqMaterialTaskMaterialsById = nfqMaterialTaskMaterialsById;
    }


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByAssigneeId() {
        return oroUserByAssigneeId;
    }

    public void setOroUserByAssigneeId(OroUser oroUserByAssigneeId) {
        this.oroUserByAssigneeId = oroUserByAssigneeId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_unit_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroBusinessUnit getOroBusinessUnitByBusinessUnitId() {
        return oroBusinessUnitByBusinessUnitId;
    }

    public void setOroBusinessUnitByBusinessUnitId(OroBusinessUnit oroBusinessUnitByBusinessUnitId) {
        this.oroBusinessUnitByBusinessUnitId = oroBusinessUnitByBusinessUnitId;
    }

@JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ticket_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqTicket getNfqTicketByTicketId() {
        return nfqTicketByTicketId;
    }

    public void setNfqTicketByTicketId(NfqTicket nfqTicketByTicketId) {
        this.nfqTicketByTicketId = nfqTicketByTicketId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByAuthorId() {
        return oroUserByAuthorId;
    }

    public void setOroUserByAuthorId(OroUser oroUserByAuthorId) {
        this.oroUserByAuthorId = oroUserByAuthorId;
    }


    @OneToMany(mappedBy = "nfqTaskByTaskId")
    public Collection<NfqTaskAssistant> getNfqTaskAssistantsById() {
        return nfqTaskAssistantsById;
    }

    public void setNfqTaskAssistantsById(Collection<NfqTaskAssistant> nfqTaskAssistantsById) {
        this.nfqTaskAssistantsById = nfqTaskAssistantsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqTaskByTaskId")
    public Collection<NfqTaskMaterial> getNfqTaskMaterialsById() {
        return nfqTaskMaterialsById;
    }

    public void setNfqTaskMaterialsById(Collection<NfqTaskMaterial> nfqTaskMaterialsById) {
        this.nfqTaskMaterialsById = nfqTaskMaterialsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqTaskByLastStartedTaskId")
    public Collection<NfqTicket> getNfqTicketsById() {
        return nfqTicketsById;
    }

    public void setNfqTicketsById(Collection<NfqTicket> nfqTicketsById) {
        this.nfqTicketsById = nfqTicketsById;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "nfqTaskByEstimateTaskId")
    public Collection<NfqTicket> getNfqTicketsById_0() {
        return nfqTicketsById_0;
    }

    public void setNfqTicketsById_0(Collection<NfqTicket> nfqTicketsById_0) {
        this.nfqTicketsById_0 = nfqTicketsById_0;
    }
}
