package com.jonas.pet.model.fms;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "nfq_task_material", schema = "platform", indexes = {
        @Index(name = "IDX_6CCC1D328DB60186", columnList = "task_id", unique = false)
})
public class NfqTaskMaterial {
    @JsonIgnore
    private int id;
    @JsonIgnore
    private int ownerId;
    @JsonIgnore
    private Integer updatedById;
    @JsonIgnore
    private Integer taskId;

    private String description;
    @JsonIgnore
    private Timestamp createdAt;
    @JsonIgnore
    private Timestamp updatedAt;
    @JsonIgnore
    private String serializedData;
    @JsonIgnore
    private OroUser oroUserByOwnerId;
    private OroUser oroUserByUpdatedById;
    private NfqTask nfqTaskByTaskId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "owner_id", nullable = false)
    public int getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(int ownerId) {
        this.ownerId = ownerId;
    }

    @Basic
    @Column(name = "updated_by_id", nullable = true)
    public Integer getUpdatedById() {
        return updatedById;
    }

    public void setUpdatedById(Integer updatedById) {
        this.updatedById = updatedById;
    }

    @Basic
    @Column(name = "task_id", nullable = true)
    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    @Basic
    @Column(name = "description", nullable = false, length = -1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "createdat", nullable = false)
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Basic
    @Column(name = "updatedat", nullable = false)
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Basic
    @Column(name = "serialized_data", nullable = true, length = -1)
    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NfqTaskMaterial that = (NfqTaskMaterial) o;

        if (id != that.id) return false;
        if (ownerId != that.ownerId) return false;
        if (updatedById != null ? !updatedById.equals(that.updatedById) : that.updatedById != null) return false;
        if (taskId != null ? !taskId.equals(that.taskId) : that.taskId != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null) return false;
        if (updatedAt != null ? !updatedAt.equals(that.updatedAt) : that.updatedAt != null) return false;
        if (serializedData != null ? !serializedData.equals(that.serializedData) : that.serializedData != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + ownerId;
        result = 31 * result + (updatedById != null ? updatedById.hashCode() : 0);
        result = 31 * result + (taskId != null ? taskId.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (serializedData != null ? serializedData.hashCode() : 0);
        return result;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id", referencedColumnName = "id", nullable = false, insertable=false, updatable=false)
    public OroUser getOroUserByOwnerId() {
        return oroUserByOwnerId;
    }

    public void setOroUserByOwnerId(OroUser oroUserByOwnerId) {
        this.oroUserByOwnerId = oroUserByOwnerId;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updated_by_id", referencedColumnName = "id", insertable=false, updatable=false)
    public OroUser getOroUserByUpdatedById() {
        return oroUserByUpdatedById;
    }

    public void setOroUserByUpdatedById(OroUser oroUserByUpdatedById) {
        this.oroUserByUpdatedById = oroUserByUpdatedById;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", referencedColumnName = "id", insertable=false, updatable=false)
    public NfqTask getNfqTaskByTaskId() {
        return nfqTaskByTaskId;
    }

    public void setNfqTaskByTaskId(NfqTask nfqTaskByTaskId) {
        this.nfqTaskByTaskId = nfqTaskByTaskId;
    }
}
