package com.jonas.pet.rep.fms;

import com.jonas.pet.model.fms.NfqTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface TaskRep extends JpaRepository<NfqTask, Integer> {


    List<NfqTask> findAllByFinishTimeBetweenAndLastStatus(Timestamp startTime, Timestamp endTime, String lastStatus);

    @Query("SELECT p, t FROM NfqTask p, NfqTicket t WHERE (p.finishTime BETWEEN :startTime and :endTime) AND p.lastStatus = 'resolved' " +
            "AND (t.workManagerId = :workManagerID) AND t.id = p.ticketId ORDER BY t.workActNumber")
    public List<NfqTask> find(Integer workManagerID, Timestamp startTime, Timestamp endTime );
}
