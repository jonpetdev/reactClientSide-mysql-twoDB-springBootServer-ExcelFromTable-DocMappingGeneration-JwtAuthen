package com.jonas.pet.rep.user;

import com.jonas.pet.model.user.TariffDB;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TariffRep extends JpaRepository<TariffDB, Long> {

    public TariffDB findByHouseExternalIDAndBusinessUnitInternalIDAndYear(Integer houseID, Integer businessUnitID,Integer year );
}
