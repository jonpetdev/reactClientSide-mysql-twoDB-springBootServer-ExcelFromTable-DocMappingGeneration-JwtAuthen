package com.jonas.pet.rep.user;

import com.jonas.pet.model.user.UserMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserMemberRep extends JpaRepository<UserMember, Long> {

    Optional<UserMember> findByUsername(String username);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);
}
