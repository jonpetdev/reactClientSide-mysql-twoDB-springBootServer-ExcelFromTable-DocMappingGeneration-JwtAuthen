package com.jonas.pet.rep.fms;



import com.jonas.pet.model.fms.NfqObject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

@Repository
public interface ObjectRep extends JpaRepository<NfqObject, Integer> {


    @Query("SELECT o FROM NfqObject o WHERE  o.isHouse = 1 and o.statusId IN (3,7,11,15,19,24,29) and (o.street Like  :address) and o.businessUnitId=:businessUnitID  and o.system = 'BB' and  o.externalId IS NOT NULL ")
    public List<NfqObject> findAllAddress(String address, Integer businessUnitID);


    public Integer countByHouseIdAndTypeIdIn(Integer houseID, List<Integer> typeIdList );

    @Query("SELECT o FROM NfqObject o WHERE o.isHouse = 1 and o.statusId IN (3,7,11,15,19,24,29) and o.businessUnitId=:businessUnitId and o.system = 'BB' and  o.externalId IS NOT NULL")
    public List<NfqObject> findObjectsBusinessUnitId(Integer businessUnitId);

}
