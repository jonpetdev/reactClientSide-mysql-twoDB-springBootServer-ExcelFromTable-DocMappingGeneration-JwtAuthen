package com.jonas.pet.rep.fms;


import com.jonas.pet.model.fms.OroBusinessUnit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BusinessUnitRep extends JpaRepository<OroBusinessUnit, Integer> {

    @Query("SELECT u FROM OroBusinessUnit u WHERE u.name like :businessUnitName ")
    public List<OroBusinessUnit> findAllBusinessUnitas(String businessUnitName);
}
