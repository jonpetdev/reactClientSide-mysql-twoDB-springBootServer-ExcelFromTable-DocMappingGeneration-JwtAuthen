package com.jonas.pet.rep.fms;

import com.jonas.pet.model.fms.OroUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRep extends JpaRepository<OroUser, Integer> {

    @Query("SELECT u, r FROM OroUser u, OroUserAccessRole r WHERE (r.roleId=7 AND r.userId = u.id ) and u.enabled=1")
    public List<OroUser> findWorkManagers();

    @Query("SELECT u, r FROM OroUser u, OroUserAccessRole r WHERE (r.roleId=7 AND r.userId = u.id ) and u.enabled=1 and u.username Like  :username")
    public List<OroUser> findSearch(String username);
}
