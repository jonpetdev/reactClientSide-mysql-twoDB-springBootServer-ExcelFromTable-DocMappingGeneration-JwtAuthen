package com.jonas.pet.rep.fms;


import com.jonas.pet.model.fms.NfqTicket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Repository
public interface TicketRep extends JpaRepository<NfqTicket, Integer> {

    List<NfqTicket> findAllByWorkManagerIdAndStatus(Integer workManagerID, String status);

    @Query("SELECT t FROM NfqTicket t WHERE  (t.workManagerId = :workManagerID) And (t.completionDate between :startTime and :endTime) and t.status IN ('closed','waiting_for_verification','waiting_for_confirmation')")
    public List<NfqTicket> find(Integer workManagerID, Timestamp startTime, Timestamp endTime );

    @Query("select t from NfqTicket t Where t.nfqObjectByObjectId.id = :objectId and t.ltFlowCategory IN ('mandatory','short_term') and t.status='planning' ")
    public List<NfqTicket> findShortTerm(Integer objectId);

    @Query("select t from NfqTicket t Where t.nfqObjectByObjectId.id = :objectId and t.ltFlowCategory IN ('mandatory','long_term','short_term') and t.status='planning' and t.workDeadline<= :dateTo")
    public List<NfqTicket> findLongTerm(Integer objectId, Date dateTo);

}
