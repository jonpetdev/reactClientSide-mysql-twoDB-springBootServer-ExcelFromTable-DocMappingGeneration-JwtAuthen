package com.jonas.pet.controller;

import com.jonas.pet.model.fms.*;
import com.jonas.pet.model.longShort.ObjectoInfoShort;
import com.jonas.pet.model.user.UserMember;
import com.jonas.pet.rep.fms.*;
import com.jonas.pet.rep.user.UserMemberRep;
import com.jonas.pet.service.ObjektoInfoService;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/live")
public class MainController {

@Autowired
private TaskRep taskRep;

@Autowired
private UserRep userRep;

@Autowired
private TicketRep ticketRep;

@Autowired
private UserMemberRep userMemberRep;

@Autowired
private ObjectRep objectRep;

@Autowired
private ObjektoInfoService objektoInfoService;

@Autowired
private BusinessUnitRep businessUnitRep;



    @RequestMapping("/search")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')  or hasRole('MODERATOR')")
    public String firstPage() {
        return "success";
    }


    @GetMapping("/workmanagers")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')  or hasRole('MODERATOR')")
    public Iterable<OroUser> getUser(){

        return userRep.findWorkManagers();
    }

    @RequestMapping("/workmanagers/search")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER') or hasRole('MODERATOR')")
    public Iterable<OroUser> getUserSearch(@RequestParam("username") String username){

        return userRep.findSearch("%"+username+"%");
    }

    @GetMapping("/tasks")
    @PreAuthorize("hasRole('ADMIN') ")
    public Iterable<NfqTask> getTasks(@RequestParam("work") Integer workManagerId ,
                                      @RequestParam("start") String startDate,
                                      @RequestParam("end") String endDate) throws ParseException {

        String pattern1 = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern1);
        Date dateStart= simpleDateFormat.parse(startDate);
        Date dateEnd= simpleDateFormat.parse(endDate);
        Timestamp timestampStart = new Timestamp(dateStart.getTime());
        Timestamp timestampEnd = new Timestamp(dateEnd.getTime());

        return taskRep.find(workManagerId, timestampStart, timestampEnd);
    }

    @GetMapping("/ticket")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER') or hasRole('MODERATOR')")
    public Iterable<NfqTicket> getTicket(@RequestParam("work") Integer workManagerId ,
                                      @RequestParam("start") String startDate,
                                      @RequestParam("end") String endDate) throws ParseException {

        String pattern1 = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern1);
        Date dateStart= simpleDateFormat.parse(startDate);
        Date dateEnd= simpleDateFormat.parse(endDate);
        Timestamp timestampStart = new Timestamp(dateStart.getTime());
        Timestamp timestampEnd = new Timestamp(dateEnd.getTime());

        return ticketRep.find(workManagerId, timestampStart, timestampEnd);
    }

    @GetMapping("/useris")
    @PreAuthorize("hasRole('ADMIN')")
    public Iterable<UserMember> getUseris(){

        return userMemberRep.findAll();
    }

    @RequestMapping("/useris/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteUser(@PathVariable("id") Long userId){
        try {
            userMemberRep.delete(userMemberRep.getOne(userId));
        }catch (NullPointerException e){
            return "error";
        }
        return "istrinta";
    }

    @RequestMapping("/object/search")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MODERATOR')")
    public Iterable<NfqObject> getObjects(@RequestParam("house") String houseAddress, @RequestParam("bu") Integer businessUnitID){

        return objectRep.findAllAddress("%"+houseAddress+"%", businessUnitID);
    }

    @RequestMapping("/object")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MODERATOR')")
    public Iterable<ObjectoInfoShort> getDataForShort(@RequestParam("house") Integer houseID, @RequestParam("year") String year) throws IOException, InvalidFormatException {
        Integer years =Integer.parseInt(year);
        return objektoInfoService.getAllForShortTermPlan(houseID, years);
    }

    @RequestMapping("/objectLong")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MODERATOR')")
    public Iterable<ObjectoInfoShort> getDataForLong(
            @RequestParam("house") Integer houseID,
            @RequestParam("dateTo") String dateTo,
            @RequestParam("year") String year) throws IOException, InvalidFormatException, ParseException {
        SimpleDateFormat format= new SimpleDateFormat("yyyyMMddhhmm");
        Date parsed= format.parse(dateTo);
        Integer years =Integer.parseInt(year);
        java.sql.Date date= new java.sql.Date(parsed.getTime());
        return objektoInfoService.getAllForLongTermPlan(houseID, date, years);
    }

    @RequestMapping("/business/search")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MODERATOR')")
    public Iterable<OroBusinessUnit> getBusinessUnitas(@RequestParam("bu") String businessUnitName){

        return businessUnitRep.findAllBusinessUnitas("%"+ businessUnitName +"%");
    }




}
