import axios from "axios";
import authHeader from "./auth-header";




const API_URL = "http://localhost:8080/ataskaita/api/";

class UserService {
  getPublicContent() {

    return axios.get(API_URL + "test/all");
  }

  getModeratorBoard() {

    return axios.get(API_URL + "test/mod", { headers: authHeader() });
  }

}

export default new UserService();
