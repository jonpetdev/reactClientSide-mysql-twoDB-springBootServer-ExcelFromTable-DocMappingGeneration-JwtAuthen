import axios from "axios";
import authHeader from "./auth-header";



const API_URL = "http://loclhost:8080/ataskaita/api/auth/";

class AuthService {
  login(username, password) {


    return axios
      .post(API_URL + "signin", { username, password })
      .then((response) => {
        if (response.data.accessToken) {
          localStorage.setItem("user", JSON.stringify(response.data));
        }

        return response.data;
      });
  }

  logout() {
    localStorage.removeItem("user");
  }

  register(username, email, password, role) {
    return axios.post(API_URL + "signup", {
      username,
      email,
      password,
      role,
    },{ headers: authHeader() });
  }
}

export default new AuthService();
