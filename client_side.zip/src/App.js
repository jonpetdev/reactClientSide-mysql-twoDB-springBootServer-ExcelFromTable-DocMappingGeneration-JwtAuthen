import React, { Component } from "react";
import { connect } from "react-redux";
import { Router, Switch, Route, Link, NavLink } from "react-router-dom";


import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import Login from "./components/login.component";
import Register from "./components/register.component";
import Home from "./components/home.component";
import Profile from "./components/profile.component";



import { logout } from "./actions/auth";
import { clearMessage } from "./actions/message";
import { history } from './helpers/history';
import GetSearchManagers from "./components/GetSearchManagers";
import GetUsersTable from "./components/GetUsersTable";
import GetSearchObject from "./components/GetSearchObject";

class App extends Component {
    constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);

        this.state = {
            showModeratorBoard: false,
            showAdminBoard: false,
            currentUser: undefined,
        };

        history.listen((location) => {
            props.dispatch(clearMessage());
        });
    }

    componentDidMount() {
        const user = this.props.user;

        if (user) {
            this.setState({
                currentUser: user,
                showModeratorBoard: user.roles.includes("ROLE_MODERATOR"),
                showAdminBoard: user.roles.includes("ROLE_ADMIN"),
            });
        }
    }

    logOut() {
        this.props.dispatch(logout());
    }

    render() {
        const { currentUser, showModeratorBoard, showAdminBoard } = this.state;

        return (
            <Router history={history}>
                <div>
                    <nav className="navbar navbar-expand navbar-dark navBaras">
                        <Link to={`${process.env.PUBLIC_URL}/`} className="navbar-brand">
                           IN OUT
                        </Link>
                        <div className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <NavLink activeClassName={"aktyvus"} to={`${process.env.PUBLIC_URL}/home`} className="nav-link navTarpas">
                                    Home
                                </NavLink>
                            </li>


                            {showModeratorBoard && (
                                <li className="nav-item">
                                    <NavLink activeClassName={"aktyvus"} to={`${process.env.PUBLIC_URL}/object`} className="nav-link navTarpas">
                                        Generate Long/Short Plans
                                    </NavLink>
                                </li>
                            )}

                            {showAdminBoard && (
                                <li className="nav-item">
                                    <NavLink activeClassName={"aktyvus"} to={`${process.env.PUBLIC_URL}/admin`} className="nav-link navTarpas">
                                        Admin
                                    </NavLink>
                                </li>

                            )}

                            {showAdminBoard &&(
                                <li className="nav-item ">
                                    <NavLink activeClassName={"aktyvus"} to={`${process.env.PUBLIC_URL}/object`} className="nav-link navTarpas">
                                        Generate Long/Short Plans
                                    </NavLink>
                                </li>
                            )}

                            {currentUser && (
                                <li className="nav-item">
                                    <NavLink activeClassName={"aktyvus"} to={`${process.env.PUBLIC_URL}/user`} className="nav-link navTarpas">
                                        Generate Workers Report
                                    </NavLink>
                                </li>
                            )}
                        </div>

                        {currentUser ? (
                            <div className="navbar-nav ml-auto">
                                <li className="nav-item">
                                    <NavLink  to={`${process.env.PUBLIC_URL}/profile`} className="nav-link">
                                        {currentUser.username}
                                    </NavLink>
                                </li>
                                <li className="nav-item">
                                    <a href={`${process.env.PUBLIC_URL}/`} className="nav-link" onClick={this.logOut}>
                                        LogOut
                                    </a>
                                </li>
                            </div>
                        ) : (
                            <div className="navbar-nav ml-auto">
                                <li className="nav-item">
                                    <NavLink activeClassName={"selected"} to={`${process.env.PUBLIC_URL}/login`} className="nav-link">
                                        Login
                                    </NavLink>

                                </li>
                            </div>
                        )}
                    </nav>

                    <div className="container mt-3">
                        <Switch>
                            <Route exact path={[`${process.env.PUBLIC_URL}/`, `${process.env.PUBLIC_URL}/home`]} component={Home} />
                            <Route exact path={`${process.env.PUBLIC_URL}/login`} component={Login} />
                            <Route exact path={`${process.env.PUBLIC_URL}/register`} component={Register} />
                            <Route exact path={`${process.env.PUBLIC_URL}/profile`} component={Profile} />
                            <Route path={`${process.env.PUBLIC_URL}/user`} component={GetSearchManagers} />
                            <Route path={`${process.env.PUBLIC_URL}/object`} component={GetSearchObject}/>
                            <Route path={`${process.env.PUBLIC_URL}/admin`} component={GetUsersTable} />
                        </Switch>
                    </div>
                </div>
            </Router>
        );
    }
}

function mapStateToProps(state) {
    const { user } = state.auth;
    return {
        user,
    };
}

export default connect(mapStateToProps)(App);
