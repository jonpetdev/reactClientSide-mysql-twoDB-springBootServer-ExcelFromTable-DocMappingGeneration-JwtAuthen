import React, {Component} from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import Logo from "./loadingimage.svg";
import isEmpty from "validator/es/lib/isEmpty";
import GetFailiukasLong from "./GetFailiukasLong";



class GetObjectInfoForDocumentLong extends Component{
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            object: props.object,
            reload: false,
            loading: true,
            selectedDateFrom: props.selectedDateFrom,
            selectedDateTo: props.selectedDateTo,
            minimumWage: props.minimumWage,
            messageStatus1: false,
            messageStatus2: false,
            messageStatus3: false,
        };
    }

    loadData = (object, selectedDateTo, year) =>{
        let dateTo= selectedDateTo.getFullYear()+""+(selectedDateTo.getMonth()+1)+""+selectedDateTo.getDate()+"2359";


        axios.get(`http://localhost:8080/ataskaita/api/live/objectLong?house=${object}&dateTo=${dateTo}&year=${year}` , { headers: authHeader() })
            .then(response => response.data)
            .then(responseData => {
                this.setState({
                    data: responseData,
                    loading: false
                });

            });
    }

    setChange=(selectedDateFrom, selectedDateTo, object, year)=>{
        let dateTo= selectedDateTo.getFullYear()+""+(selectedDateTo.getMonth()+1)+""+selectedDateTo.getDate()+"2359";


        axios.get(`http://localhost:8080/ataskaita/api/live/objectLong?house=${object}&dateTo=${dateTo}&year=${year}` , { headers: authHeader() })
            .then(response => response.data)
            .then(responseData => {
                this.setState({
                    data: responseData,
                    selectedDateFrom: selectedDateFrom,
                    selectedDateTo:selectedDateTo,
                    loading: false,

                });

            });
    }


    componentDidMount() {
        if(this.props.reload ===true) {
            this.loadData(this.props.object, this.props.selectedDateTo, (this.props.selectedDateFrom.getFullYear()).toString());
        }
    }

    render() {

        let messageInfo="";

        let docInfo=[];
        let accumulatedFundTariff, preliminaryCollumn1=0.0,preliminaryCollumn2=0.0, imokosTarifas=0.0, houseAddress, floorCount, flatCount, nonFlatCount,
        houseArea, constructionYear, selectedDateFrom, selectedDateTo, nt, minimumWage, mx, kaupimoTarifas, lTPlenghtInYears;
        let ticketList=[];



        function gettinameLong() {
            docInfo={
                accumulatedFundTariff:accumulatedFundTariff,
                preliminaryCollumn1: Number(preliminaryCollumn1).toFixed(2),
                preliminaryCollumn2: Number(preliminaryCollumn2).toFixed(4),
                imokosTarifas:imokosTarifas,
                houseAddress:houseAddress,
                houseArea:houseArea,
                floorCount:floorCount,
                flatCount:flatCount,
                nonFlatCount:nonFlatCount,
                constructionYear: constructionYear,
                selectedDateFrom: selectedDateFrom.getFullYear()+"-"+(selectedDateFrom.getMonth()+1)+"-"+selectedDateFrom.getDate(),
                selectedDateTo: selectedDateTo.getFullYear()+"-"+(selectedDateTo.getMonth()+1)+"-"+selectedDateTo.getDate(),
                selectedDateFromYear:  selectedDateFrom.getFullYear(),
                selectedDateToYear:  selectedDateTo.getFullYear(),
                nt: nt,
                ticket: ticketList,
                minimumWage: minimumWage,
                mx:Number(mx).toFixed(4),
                kaupimoTarifas:Number(kaupimoTarifas).toFixed(4),
                messageInfo: messageInfo,
                lTPlenghtInYears:lTPlenghtInYears,
            }


            const data=new GetFailiukasLong(docInfo);

            return(data.onClickReport());


        }

        function monthDrifftMX(selectedDateFrom, selectedDateTo){
            let months;
            months = (selectedDateTo.getFullYear() - selectedDateFrom.getFullYear()) *12;
            months -= selectedDateFrom.getMonth()-1;
            months += selectedDateTo.getMonth()

            return months <= 0 ? 0 : months;
        }

        function plusOneYear(selectedDateTo){

            let year = selectedDateTo.getFullYear();
            let month = selectedDateTo.getMonth();
            let day =selectedDateTo.getDate();
            let date = new Date((year+1), month, day);
            return date;
        }


        if (this.state.loading === true) {
            return (
                <div style={{width:"100%",
                    height:"100%",
                    display: "flex" ,
                    justifyContent: "center",
                    backgroundColor:"rgba(0, 0, 0, 0.53)",
                    position:"fixed",
                    top:"0px",
                    left:"0px",
                    zIndex:"999999999",
                }   }>
                    <img src={Logo} alt={"logo"} />
                </div>
            );

        } else {
            let ticketSkaicius=0;
            let skaicius=0;



            this.state.data.map(ob=>{

                if(ob.tariff==null){
                    return (<p>
                        Nėra Tarifo Duomenų Šiam Objektui!
                    </p>);
                }else {

                    selectedDateFrom = this.state.selectedDateFrom;
                    selectedDateTo = this.state.selectedDateTo;
                    nt = monthDrifftMX(selectedDateFrom, selectedDateTo);

                    ob.planningTickets.map(long => {
                        ticketSkaicius++;

                        let price;

                        if (long.price == null) {
                            price = parseFloat("0");
                        } else if (isEmpty(long.price)) {
                            price = parseFloat("0");
                        } else {
                            price = parseFloat(long.price);
                        }

                        preliminaryCollumn1 = preliminaryCollumn1 + price;
                        preliminaryCollumn2 = preliminaryCollumn2 + (price / ob.nfqObject.area);

                        let pastabosTicket = "-";

                        let sumCell1 = price / ob.nfqObject.area;
                        let sumCell2 = price / ob.nfqObject.area / nt;
                        let workD = new Date(long.workDeadline);
                        let workDeadline;

                        if((workD.getMonth()+1).toString().length===1){
                            workDeadline = workD.getFullYear() + "-0" + (workD.getMonth() + 1) + "-" + workD.getDate();
                        }else{
                            workDeadline = workD.getFullYear() + "-" + (workD.getMonth() + 1) + "-" + workD.getDate();
                        }


                        ticketList = ticketList.concat({
                            id: long.id,
                            sumCell1: Number(sumCell1).toFixed(4),
                            sumCell2: Number(sumCell2).toFixed(4),
                            title: long.title,
                            price: Number(price).toFixed(2),
                            workDeadline: workDeadline,
                            description: long.description,
                            pastabos: pastabosTicket,
                            sk: ticketSkaicius,
                            ltFlowCategory: long.ltFlowCategory
                        });

                        imokosTarifas = imokosTarifas + sumCell2;

                    });

                    kaupimoTarifas = imokosTarifas + ob.tariff.accumulatedFundTariff;
                    accumulatedFundTariff = Number(ob.tariff.accumulatedFundTariff).toFixed(4);
                    houseAddress = ob.nfqObject.street + " " + ob.nfqObject.houseNumber + ob.nfqObject.houseLetter;
                    houseArea = ob.nfqObject.area;
                    floorCount = ob.nfqObject.floorCount;
                    flatCount = ob.flatCount;
                    nonFlatCount = ob.nonFlatCount;
                    constructionYear = ob.nfqObject.constructionYear;
                    minimumWage = this.state.minimumWage;
                    mx = 0.05 * Number(minimumWage) / 45;
                    lTPlenghtInYears = nt / 12;

                    if (mx < kaupimoTarifas && nt > 120) {
                        this.setChange(selectedDateFrom, selectedDateTo, this.state.object, (selectedDateFrom.getFullYear()-1).toString());
                    } else if (mx < kaupimoTarifas && nt < 120) {
                        selectedDateTo = plusOneYear(selectedDateTo);
                        this.setChange(selectedDateFrom, selectedDateTo, this.state.object, (selectedDateFrom.getFullYear()-1).toString());
                    }

                    if (nt <= 60) {
                        messageInfo = "Kadangi apskaičiuotas mėnesinės kaupiamosios įmokos tarifas nėra didesnis už maksimalų " + Number(mx).toFixed(4) + ", siūloma patvirtinti mėnesinį kaupiamosios įmokos tarifą (laikotarpiui iki " + selectedDateTo.getFullYear() + "-" + (selectedDateTo.getMonth() + 1) + "-" + selectedDateTo.getDate() + ") " + Number(kaupimoTarifas).toFixed(4) + " Eur/kv. m/mėn.";
                    } else if (nt > 60 && nt <= 120) {
                        messageInfo = "nuo 5 iki 10 "
                    } else if (nt > 120) {
                        messageInfo = "virs 10 metu"
                    }
                }

            });

            return (

                <div>
                    {this.state.data.map(ob=>{

                        if(ob.tariff==null){
                            return (<p>
                                Nėra Tarifo Duomenų Šiam Objektui!
                            </p>);
                        }else {
                            return (
                                <div>
                                <div key={ob.nfqObject.id}>
                                    <h2>MĖNESINĖS KAUPIAMOSIOS ĮMOKOS TARIFO APSKAIČIAVIMAS</h2>
                                    <br/>
                                    <p>Objektas: daugiabutis gyvenamasis namas {ob.nfqObject.street} {ob.nfqObject.houseNumber} {ob.nfqObject.houseLetter}, <input onChange={(evt) => { floorCount= evt.target.value; }} defaultValue={floorCount}/> aukštų, {ob.flatCount} butų ir {ob.nonFlatCount} kitų patalpų, namo patalpų naudingasis plotas ‒ {ob.nfqObject.area} kv. m, pastatytas <input onChange={(evt) => { constructionYear= evt.target.value; }} defaultValue={constructionYear}/> m.</p>
                                    <p>Bendrojo naudojimo objektų atnaujinimo pagal privalomuosius statinių naudojimo ir priežiūros reikalavimus {this.state.selectedDateFrom.getFullYear()+"-"+(this.state.selectedDateFrom.getMonth()+1)+"-"+this.state.selectedDateFrom.getDate()} : {this.state.selectedDateTo.getFullYear()+"-"+(this.state.selectedDateTo.getMonth()+1)+"-"+this.state.selectedDateTo.getDate()} ({this.state.selectedDateFrom.getFullYear()}‒{this.state.selectedDateTo.getFullYear()} m), {nt/12} metams. ilgalaikis planas:</p>
                                    <br/>

                                    <table className={"table table-sm table-condensed"}>
                                        <thead className={"thead-dark"}>
                                        <tr>
                                            <th>Eil. Nr.</th>
                                            <th>Darbų pavadinimas</th>
                                            <th>Trumpas darbų apibūdinimas (darbų mastas kt.)</th>
                                            <th>Planuojamas darbų atlikimo terminas (m., mėn.)</th>
                                            <th>
                                                <table>
                                                    <thead>
                                                    <tr>
                                                        <td colSpan={"2"}>Preliminari darbų kaina</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Eur</td>
                                                        <td>Eur/kv. m</td>
                                                    </tr>
                                                    </thead>
                                                </table>
                                            </th>
                                            <th>Mėnesinės kaupiamosios įmokos tarifas, Eur/kv. m/mėn.</th>
                                            <th>Ticket id</th>
                                            <th>Flow kategorija</th>
                                            <th>Pastabos (darbų pagrindas)</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        {ticketList.map(long=>{
                                            skaicius++;

                                            function deadlinas(dateFrom) {
                                                if (dateFrom> new Date(long.workDeadline)) {
                                                    return(
                                                        <td style={{color:"red"}}>{new Date(long.workDeadline).getFullYear()+"-"+(new Date(long.workDeadline).getMonth()+1)+"-"+new Date(long.workDeadline).getDate()}</td>
                                                    )
                                                }else{
                                                    return(
                                                        <td>{new Date(long.workDeadline).getFullYear()+"-"+(new Date(long.workDeadline).getMonth()+1)+"-"+new Date(long.workDeadline).getDate()}</td>
                                                    )
                                                }
                                            }

                                            function preliminaryPrice(prelPrice){
                                                if(prelPrice==="0.00") {
                                                    return (
                                                        <td style={{color: "red"}}>{prelPrice}</td>
                                                    );
                                                }else{
                                                    return(
                                                        <td>{prelPrice}</td>
                                                    );
                                                }
                                            }

                                            return(
                                                <tr key={long.id}>
                                                    <td>{skaicius}</td>
                                                    <td>{long.title}</td>
                                                    <td>{long.description}</td>
                                                    {deadlinas(this.state.selectedDateFrom)}
                                                    <td>
                                                        <table>
                                                            <tbody>
                                                            <tr>
                                                                {preliminaryPrice(Number(long.price).toFixed(2))}
                                                                <td>{Number(long.price / ob.nfqObject.area).toFixed(4)}</td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td>{Number(long.price / ob.nfqObject.area / nt).toFixed(4)}</td>
                                                    <td><a href={"https://fms.civinity.lt/tickets/view/"+long.id} target={"_blank"} rel="noopener noreferrer">{long.id}</a></td>
                                                    <td>{long.ltFlowCategory}</td>
                                                    <td><textarea rows={"6"}  key={long.id} placeholder={"Pastabos"} onChange={(evt) => { ticketList.find(x => x.id === long.id).pastabos= evt.target.value; }}/></td>
                                                </tr>
                                            );
                                        })}

                                        <tr>
                                            <td></td>
                                            <td colSpan={"3"}>Lėšų kaupimas šiame plane nenumatytiems privalomiesiems darbams (avariniai darbai, siūlių liftų remontas ir kt.)</td>
                                            <td></td>
                                            <td>{Number(ob.tariff.accumulatedFundTariff).toFixed(4)}</td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colSpan={"4"}>Iš viso</td>
                                            <td>
                                                <table>
                                                    <tbody>
                                                    <tr>
                                                        <td>{Number(preliminaryCollumn1).toFixed(2)}</td>
                                                        <td>{Number(preliminaryCollumn2).toFixed(4)}</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td>{Number(kaupimoTarifas).toFixed(2)}</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        </tbody>
                                    </table>



                                </div>
                                    <br/>
                                    <p>{messageInfo}</p>
                                    <br/>

                                    <div style={{margin: "50px"}}>
                                        <button className={"btn btn-primary"} onClick={gettinameLong}>Export .docx</button>
                                    </div>

                                </div>
                            )}



                            })
                        }





                </div>
            );
        }
        }
    }
export default GetObjectInfoForDocumentLong;