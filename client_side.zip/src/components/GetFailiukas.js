import React from 'react';

import JSZipUtils from 'jszip-utils';

import PizZip from 'pizzip';
import expressions from 'angular-expressions';
import Docxtemplater from 'docxtemplater';
import saveAs from 'file-saver';





class GetFailiukas extends React.Component {
constructor(props) {
    super(props);
    this.state={
        data:{
            houseAddress: props.houseAddress,
            selectedDate: props.selectedDate,
            autoGenNo: props.autoGenNo,
            businessUnitAddress: props.businessUnitAddress,
            businessUnitName: props.businessUnitName,
            selectedDateYear: props.selectedDateYear,
            houseArea: props.houseArea,
            constructionYear: props.constructionYear,
            floorCount: props.floorCount,
            flatCount: props.flatCount,
            nonFlatCount: props.nonFlatCount,
            totalArea: props.totalArea,
            area: props.area,
            landArea: props.landArea,
            propRegDate: props.propRegDate,
            tariff1_1: props.tariff1_1,
            tariff1_2: props.tariff1_2,
            tariff2_1: props.tariff2_1,
            tariff2_2: props.tariff2_2,
            tariff3_1: props.tariff3_1,
            tariff3_2: props.tariff3_2,
            tariff4_1: props.tariff4_1,
            tariff4_2: props.tariff4_2,
            tariff5_1: props.tariff5_1,
            tariff5_2: props.tariff5_2,
            tariff6_1: props.tariff6_1,
            tariff6_2: props.tariff6_2,
            tariff7_1: props.tariff7_1,
            tariff7_2: props.tariff7_2,
            tariff8_1: props.tariff8_1,
            tariff8_2: props.tariff8_2,
            tariff9_1: props.tariff9_1,
            tariff9_2: props.tariff9_2,
            sum1: props.sum1,
            sum2: props.sum2,
            sum3: props.sum3,
            ticket: props.ticket,
            accFundTariff: props.accFundTariff,
            accFundBalance: props.accFundBalance,
            planuojamu3punktoSum: props.planuojamu3punktoSum,
            antroSkyr3: props.antroSkyr3,
            antroSkyr4: props.antroSkyr4,
            antroSkyr5: props.antroSkyr5,
            antroSkyrPastabos: props.antroSkyrPastabos,
            pirmoSkyr3punktoPastabos: props.pirmoSkyr3punktoPastabos,
            pirmoSkyr1Pastabos1:  props.pirmoSkyr1Pastabos1,
            pirmoSkyr1Pastabos2: props.pirmoSkyr1Pastabos2,
            pirmoSkyr1Pastabos3: props.pirmoSkyr1Pastabos3 ,
            pirmoSkyr1Pastabos4: props.pirmoSkyr1Pastabos4,
            pirmoSkyr1Pastabos5: props.pirmoSkyr1Pastabos5 ,
            pirmoSkyr1Pastabos6: props.pirmoSkyr1Pastabos6 ,
            pirmoSkyr1Pastabos7:  props.pirmoSkyr1Pastabos7,
            pirmoSkyr1Pastabos8:  props.pirmoSkyr1Pastabos8,
            pirmoSkyr1Pastabos9:  props.pirmoSkyr1Pastabos9,


        }
    }


}

componentDidMount() {
    this.onClickReport();
}


    loadFile(url, callback) {
        JSZipUtils.getBinaryContent(url, callback);
    }

    onClickReport = () => {

        const angularParser = function (tag) {
            return {
                get: tag === '.' ? function (s) {
                    return s;
                } : function (s) {
                    return expressions.compile(tag.replace(/(’|“|”)/g, "'"))(s);
                }
            };
        };

        const info= this.state.data;

        this.loadFile("http://localhost:8080/files/Short_term_doc.docx", function (error, content) {
            if (error) {
                throw error;
            }
            function replaceErrors(key, value) {
                if (value instanceof Error) {
                    return Object.getOwnPropertyNames(value).reduce(function(error, key) {
                        error[key] = value[key];
                        return error;
                    }, {});
                }
                return value;
            }
            function errorHandler(error) {
                console.log(JSON.stringify({error: error}, replaceErrors));

                if (error.properties && error.properties.errors instanceof Array) {
                    const errorMessages = error.properties.errors.map(function (error) {
                        return error.properties.explanation;
                    }).join("\n");
                    console.log('errorMessages', errorMessages);
                }
                throw error;
            }


            const zip = new PizZip(content);
            const doc = new Docxtemplater().loadZip(zip)
                .setOptions({
                    paragraphLoop: true,
                    parser: angularParser
                });


console.log(info)


            doc.setData(
                info
            );

            try {
                doc.render();
            } catch (error) {
                errorHandler(error);
            }


            const out = doc.getZip().generate({
                type: "blob",
                mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            });
            saveAs(out, "Short Term Plan-"+info.houseAddress+".docx");



        });



    }

render() {
    return(this.onClickReport())

}
}
export default GetFailiukas;