import React, {Component} from "react";
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import axios from "axios";
import authHeader from "../services/auth-header";
import Logo from './loadingimage.svg';



class GetTasksTable extends Component{
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            manager: null,
            startDate: null,
            endDate: null,
            reload: false,
            loading: true,
            dataForValue: [{aktoNr: null, adresas: null, pavadinimas: null, visoSuma: null, medz: null, darb: null, mech: null, visiDarbuotojai: null, darbuotojuSkaicius: null}]
        };
    }


    loadData = (manager,startDate,endDate) =>{

        axios.get(`http://localhost:8080/ataskaita/api/live/ticket?work=${manager}&start=${startDate}&end=${endDate}` , { headers: authHeader() })
            .then(response => response.data)
            .then(responseData => {
                this.setState({
                    data: responseData,
                    loading: false
                });

            });
    }


    componentDidMount() {
        if(this.props.reload ===true) {
            this.loadData(this.props.manager, this.props.startDate, this.props.endDate);
        }
    }





    render() {

        if (this.state.loading === true) {
            return (
                <div style={{width:"100%",
                    height:"100%",
                    display: "flex" ,
                    justifyContent: "center",
                    backgroundColor:"rgba(0, 0, 0, 0.53)",
                    position:"fixed",
                    top:"0px",
                    left:"0px",
                    zIndex:"999999999",
                }   }>
                    <img src={Logo} alt={"logo"} />
                </div>
            );

        } else {

            let work=0;
            let mechanism=0;
            let material=0;
            let empl=[];
            let emplKaina=[{vardas:'', kaina:''}];
            let emplAtaskaita=[{vardas:'', bendraDarbuSuma:''}];


            function setToNullEmpl(){
                empl=[];
            }

            function setToNullMaterials() {
                work=0;
                mechanism=0;
                material=0;
            }

            function retuu(kiekis, kaina) {
                let bendra= kaina / kiekis;

                return bendra;
            }

            function ifEmploNotOne() {
                let sk=0;
                    return <td style={{border: 'solid 1px'}}>{empl.map(m => {
                        if(sk===0){
                            sk++;
                            return m;
                        }else{
                            return ", "+m;
                        }
                    })}</td>

            }


            return (<div>

                    <div>
                        <ReactHTMLTableToExcel
                            className={"btnKlase"}
                            table={"emp"}
                            filename={"ReportExcel"}
                            sheet={"Sheet"}
                            buttonText={" "}

                        />
                    </div>
                <table id={"emp"} className={"table table-sm table-condensed"} >
                    <thead className={"thead-dark"}>
                    <tr>
                        <th>Ticket ID</th>
                        <th>Akto Numeris</th>
                        <th>Adresas</th>
                        <th>Darbų Pavadinimas</th>
                        <th>Viso Darbai Su Medžiagomis</th>
                        <th>Mechanizmai</th>
                        <th>Medžiagos</th>
                        <th>Darbas</th>
                        <th>Visi Dirbę darbuotojai</th>
                    </tr>
                    </thead>
                    <tbody>

                    {this.state.data.map(item =>
                        <tr key={item.id}>
                            <div style={{display:'none'}}>{setToNullMaterials()} {setToNullEmpl()}</div>
                            <td style={{border: 'solid 1px'}}><a target={"_blank"} rel="noopener noreferrer" href={"https://fms.civinity.lt/tickets/view/"+item.id}>{item.id}</a></td>
                            <td style={{border: 'solid 1px'}}>{item.workActNumber}</td>
                            <td style={{border: 'solid 1px'}}>{item.nfqObjectByObjectId.city},
                                {item.nfqObjectByObjectId.street}
                                {item.nfqObjectByObjectId.houseNumber}
                            </td>
                            <td style={{border: 'solid 1px'}}>{item.nfqTasksById.map(itt =>
                            {if(itt.taskType==='delivery_act'){
                                itt.nfqMaterialTaskMaterialsById.map(mat =>{
                                    if(mat.nfqMaterialByMaterialId.type==="work") {
                                        console.log(mat.price);
                                        work = work + mat.price;
                                        return null;
                                    }else if(mat.nfqMaterialByMaterialId.type==="mechanism") {
                                        console.log(mat.price);
                                        mechanism = mechanism + mat.price;
                                        return null;
                                    }else if(mat.nfqMaterialByMaterialId.type==="material"){
                                        console.log(mat.nfqMaterialByMaterialId.price);
                                        material=material+mat.price;
                                    }else{
                                        return null;
                                    }
                                return null;
                                });

                                return null;
                            }else {
                                let assign = itt.oroUserByAssigneeId.firstName+" "+itt.oroUserByAssigneeId.lastName;
                                if(empl.includes(assign)){

                                }else {
                                    empl.push(assign);
                                }

                                if(itt.nfqTaskAssistantsById!=null){
                                    itt.nfqTaskAssistantsById.map(ass => {
                                        let assistant = ""+ass.nfqEmployeeByEmployeeId.firstName+" "+ass.nfqEmployeeByEmployeeId.lastName;
                                        if(empl.includes(assistant)){

                                        }else{
                                            empl.push(assistant);
                                        }

                                    });
                                }

                                return (
                                    <div style={{display:"block"}} key={itt.id}>
                                        <div style={{ borderBottom: 'solid 1px', display: "inline", marginRight: "10px"}}><a target={"_blank"} rel="noopener noreferrer" href={"https://fms.civinity.lt/tickets/tasks/view/"+itt.id}>{itt.id}</a></div>
                                        <div style={{ borderBottom: 'solid 1px', display: "inline"}}>{itt.title}</div>
                                    </div>
                                );
                            }
                            }

                            )}</td>
                            <td style={{border: 'solid 1px'}}>{item.actualPrice}</td>
                            <td style={{border: 'solid 1px'}}>{mechanism}</td>
                            <td style={{border: 'solid 1px'}}>{material}</td>
                            <td style={{border: 'solid 1px'}}>{work}</td>

                            {ifEmploNotOne()}

                            {empl.map(m =>{
                                emplKaina.push({vardas: m, kaina: retuu(empl.length, work)});
                                return null;
                            })}

                        </tr>
                    )}

                    {emplKaina.map(m =>
                        {
                            if(emplAtaskaita.filter(e=>e.vardas === m.vardas).length>0){
                                let obj = emplAtaskaita.find(obj => obj.vardas === m.vardas);
                                obj.bendraDarbuSuma=obj.bendraDarbuSuma + m.kaina;
                                return null;
                            }else{
                                emplAtaskaita.push({vardas: m.vardas, bendraDarbuSuma: m.kaina});
                                return null;
                            }
                        }
                    )}

                    {emplAtaskaita.map(m=>
                        <tr>
                            <td>{m.vardas}</td>
                            <td>{m.bendraDarbuSuma}</td>
                            </tr>
                    )}

                    </tbody>
                </table>

                </div>
            );
        }
    }


}
export default GetTasksTable;