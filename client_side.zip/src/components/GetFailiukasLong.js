import React from 'react';

import JSZipUtils from 'jszip-utils';

import PizZip from 'pizzip';
import expressions from 'angular-expressions';
import Docxtemplater from 'docxtemplater';
import saveAs from 'file-saver';





class GetFailiukasLong extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            data:{
                accumulatedFundTariff: props.accumulatedFundTariff,
                preliminaryCollumn1:props.preliminaryCollumn1,
                preliminaryCollumn2:props.preliminaryCollumn2,
                imokosTarifas:props.imokosTarifas,
                houseAddress:props.houseAddress,
                houseArea:props.houseArea,
                floorCount:props.floorCount,
                flatCount:props.flatCount,
                nonFlatCount:props.nonFlatCount,
                constructionYear: props.constructionYear,
                selectedDateFrom: props.selectedDateFrom,
                selectedDateTo: props.selectedDateTo,
                selectedDateFromYear: props.selectedDateFromYear,
                selectedDateToYear:  props.selectedDateToYear,
                nt: props.nt,
                ticket: props.ticket,
                minimumWage: props.minimumWage,
                mx:props.mx,
                kaupimoTarifas:props.kaupimoTarifas,
                messageInfo: props.messageInfo,
                lTPlenghtInYears:props.lTPlenghtInYears,

            }
        }


    }

    componentDidMount() {
        this.onClickReport();
    }


    loadFile(url, callback) {
        JSZipUtils.getBinaryContent(url, callback);
    }

    onClickReport = () => {

        const angularParser = function (tag) {
            return {
                get: tag === '.' ? function (s) {
                    return s;
                } : function (s) {
                    return expressions.compile(tag.replace(/(’|“|”)/g, "'"))(s);
                }
            };
        };

        const info= this.state.data;

        this.loadFile("http://localhost:8080/files/Long_term_doc.docx", function (error, content) {
            if (error) {
                throw error;
            }
            function replaceErrors(key, value) {
                if (value instanceof Error) {
                    return Object.getOwnPropertyNames(value).reduce(function(error, key) {
                        error[key] = value[key];
                        return error;
                    }, {});
                }
                return value;
            }
            function errorHandler(error) {
                console.log(JSON.stringify({error: error}, replaceErrors));

                if (error.properties && error.properties.errors instanceof Array) {
                    const errorMessages = error.properties.errors.map(function (error) {
                        return error.properties.explanation;
                    }).join("\n");
                    console.log('errorMessages', errorMessages);

                }
                throw error;
            }

            const zip = new PizZip(content);
            const doc = new Docxtemplater().loadZip(zip)
                .setOptions({
                    paragraphLoop: true,
                    parser: angularParser
                });


            console.log(info)


            doc.setData(
                info
            );

            try {
                doc.render();
            } catch (error) {
                errorHandler(error);
            }


            const out = doc.getZip().generate({
                type: "blob",
                mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            });
            saveAs(out, "Long Term Plan-"+info.houseAddress+".docx");



        });



    }

    render() {
        return(this.onClickReport())

    }
}
export default GetFailiukasLong;