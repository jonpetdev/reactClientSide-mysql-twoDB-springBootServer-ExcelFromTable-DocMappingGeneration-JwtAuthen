import React, {useState} from 'react'
import AsyncSelect from 'react-select/async';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import GetTasksTable from "./GetTasksTable";
import axios from "axios";
import authHeader from "../services/auth-header";



function GetSearchManagers() {

    const [inputValue, setValue] = useState('');
    const [selectedValue, setSelectedValue] = useState(null);
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(null);
    const [buttonas, setButtonas] = useState(false);


    const handleInputChange = value => {
        setValue(value);
    };

    const changas = () =>{
        if(buttonas === false){
            setButtonas(true);
        }else{
            setButtonas(false);
        }
    };


    function showGenerateButton(endDate, selectedManager){
        if(endDate!=null && selectedManager!=null){
            return(
                <div style={{float:"right", margin:"20px"}}>
                    <button className={"btn btn-success"} onClick={changas}>Generate Work Report</button>
                </div>
            );
        }
    }


    const mygtukas=()=>{
        if(buttonas === false){
            return (
                <div className="App">
                    <div style={{marginLeft:"20px", marginRight:"20px"}}>
                        <label><strong>Choose Work Manager</strong></label>
                        <AsyncSelect
                            cacheOptions
                            defaultOptions
                            value={selectedValue}
                            getOptionLabel={e => e.username}
                            getOptionValue={e => e.username}
                            loadOptions={loadOptions}
                            onInputChange={handleInputChange}
                            onChange={handleChange}
                        />
                    </div>
                    <div style={{ width: "50%", display:"inline"}}>
                        <div style={{float:"left", marginLeft:"20px"}}>
                            <label><strong>Date From:</strong></label>
                            <div><DatePicker
                                selected={startDate}
                                onChange={date => setStartDate(date)}
                                selectsStart
                                startDate={startDate}
                                endDate={endDate}
                                dateFormat="yyyy-MM-dd"/>
                            </div>
                        </div>
                        <div style={{float:"left", marginLeft:"20px"}}>
                            <label><strong>Date To:</strong></label>
                            <div><DatePicker
                            selected={endDate}
                            onChange={date => setEndDate(date)}
                            selectsEnd
                            startDate={startDate}
                            endDate={endDate}
                            minDate={startDate}
                            dateFormat="yyyy-MM-dd"/>
                            </div>
                        </div>
                    </div>

                    {showGenerateButton(endDate, selectedValue)}

                </div>

            );
        }else{


            return (
                <div style={{width: "100%"}}>
                    <div >
                        <button className={"btn btn-success"} onClick={changas} style={{margin:"0 auto", display:"block"}}>Back to Selection</button>
                    </div>
                    {showTable()}
                </div>
                );
        }
    }

    const handleChange = value => {
        setSelectedValue(value);
    }


    const loadOptions = (inputValue) => {

        return axios.get(`http://localhost:8080/ataskaita/api/live/workmanagers/search?username=${inputValue}`, { headers: authHeader() })
            .then(res => res.data);
    };



    const showTable = () =>{
        if(selectedValue != null && endDate !=null && buttonas === true){
            return <GetTasksTable
                reload={buttonas}
                manager={selectedValue.id}
                startDate={startDate.getFullYear()+"-"+(startDate.getMonth()+1)+"-"+startDate.getDate()}
                endDate={endDate.getFullYear()+"-"+(endDate.getMonth()+1)+"-"+endDate.getDate()}
            />;
        }
    }



    return (
        <div>
            {mygtukas()}
        </div>

    );
}


    export  default GetSearchManagers;