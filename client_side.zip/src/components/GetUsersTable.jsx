import React, {Component} from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import Logo from "./loadingimage.svg";





class GetUsersTable extends Component{
    constructor(props) {
        super(props);
        this.state= {
            data: [],
            loading: true,
            reload: false,
            message123: '',
        }
    }

        loadData = () =>{


            axios.get(`http://localhost:8080/ataskaita/api/live/useris` , { headers: authHeader() })
                .then(response => response.data)
                .then(responseData => {
                    this.setState({
                        data: responseData,
                        loading: false,
                    });

                });
        }



    componentDidMount() {
        this.loadData();
    }

    routeChange=()=> {
        this.props.history.push(`${process.env.PUBLIC_URL}/register`);
    }



    handleClick = userId => {
        axios.get("http://localhost:8080/ataskaita/api/live/useris/delete/"+userId, { headers: authHeader() } )
            .then(response => response.data)
            .then(responseData => {
                this.setState({
                    message123: responseData,
                });
                this.loadData();
            });

    }



    render() {

        function setMessa(message) {
            if(message!=null){
                        if(message==="istrinta"){
                            return <div style={{width:"100%", backgroundColor: "#9fc693", border:"solid 1px #cbcba9", borderRadius:"3px", height:"30px", textAlign: "center"}}><p style={{color: "green", margin:"auto"}}>{message}</p></div>;
                        }else{
                            return <p style={{color: "red"}}>{message}</p>;
                        }
            }



        }

        if (this.state.loading === true) {
            return (
                <div style={{width:"100%",
                    height:"100%",
                    display: "flex" ,
                    justifyContent: "center",
                    backgroundColor:"rgba(0, 0, 0, 0.53)",
                    position:"fixed",
                    top:"0px",
                    left:"0px",
                    zIndex:"999999999",
                }   }>
                    <img src={Logo} alt={"logo"} />
                </div>
            );

        } else {


            return (
                <div>
                    {setMessa(this.state.message123)}
                    <div style={{margin:"10px", float:"right"}}>
                        <button onClick={this.routeChange} className={"btn btn-primary"}>
                            Create User
                        </button>
                    </div>
                    <table id={"user"} className={"table table-sm"} >
                        <thead className={"thead-dark"}>
                        <tr>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>e-mail</th>
                            <th>Roles</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>

                        {this.state.data.map(item =>
                            <tr key={item.id}>
                                <td style={{border: 'solid 1px'}}>{item.id}</td>
                                <td style={{border: 'solid 1px'}}>{item.username}</td>
                                <td style={{border: 'solid 1px'}}>{item.email}</td>
                                <td style={{border: 'solid 1px'}}>{item.roles.map(role=>
                                role.name
                                )}
                                </td>
                                <td style={{border: 'solid 1px'}}><button onClick={() => {this.handleClick(item.id) }}>istrinti</button></td>
                            </tr>
                        )}
                            </tbody>
                    </table>
                </div>
            );
        }
    }
}

export default GetUsersTable;