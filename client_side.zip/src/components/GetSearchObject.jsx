import React, {useState} from 'react'
import AsyncSelect from 'react-select/async';
import axios from "axios";
import authHeader from "../services/auth-header";
import GetObjectInfoForDocument from "./GetObjectInfoForDocument";
import GetObjectInfoForDocumentLong from "./GetObjectInfoForDocumentLong";
import DatePicker from "react-datepicker";
import { Button, Modal } from 'react-bootstrap';



function GetSearchObject() {

    const [inputValue, setValue] = useState('');
    const [inputBuValue, setBuValue] = useState('');
    const [selectedBuValue, setSelectedBuValue] = useState(null);
    const [selectedObjectValue, setSelectedObjectValue] = useState(null);
    const [buttonas, setButtonas] = useState(false);
    const [buttonas2, setButtonas2] = useState(false);
    const [selectedDateShort, setSelectedDateShort] = useState(new Date(new Date().getFullYear(), 0,1));
    const [selectedDateFrom, setSelectedDateFrom] = useState('');
    const [selectedDateTo, setSelectedDateTo] = useState('');
    const [minimumWage, setMinimumWage] = useState('');





    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [showLong, setShowLong] = useState(false);
    const handleCloseLong = () => setShowLong(false);
    const handleShowLong = () => setShowLong(true);


    const handleInputChange = value => {
        setValue(value);
    };

    const handleInputBuChange = value2 =>{
      setBuValue(value2);
    };


    const modalas=()=>{

        return(
            <>
                <Modal show={show} onHide={handleClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Short Term Plan Document Date</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div style={{ width: "50%", display:"inline"}}>
                            <div style={{float:"left", marginLeft:"20px"}}>

                        <DatePicker
                            selected={selectedDateShort}
                            onChange={date => setSelectedDateShort(date)}
                            showMonthDropdown={true}
                            minDate={new Date(new Date().getFullYear(), 0,1)}
                            dateFormat="yyyy-MM-dd" />
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={handleClose}>
                            Close
                        </Button>
                        <Button variant="primary" onClick={changas}>
                            Next
                        </Button>
                    </Modal.Footer>
                </Modal>
            </>
        );
    }

    function showNextButton(dateFrom, dateTo, mma) {

        if(dateTo!=='' && dateFrom!=='' && mma!==''){
            return(
                <Button variant="primary" onClick={changas2}>
                    Next
                </Button>
            );
        }else{

        }
    }

    const modalasLong=()=>{

        return(
            <>
                <Modal show={showLong} onHide={handleCloseLong}>
                    <Modal.Header closeButton>
                        <Modal.Title>Long Term Plan</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div style={{ width: "50%", display:"inline"}}>
                            <div style={{float:"left", marginLeft:"20px"}}>
                                <div>Date From:</div>
                        <DatePicker
                            selected={selectedDateFrom}
                            onChange={date => setSelectedDateFrom(date)}
                            minDate={new Date((new Date().getFullYear()),0,1)}
                            showMonthDropdown={true}
                            showYearDropdown={true}
                            dateFormat="yyyy-MM-dd" />
                            </div>
                            <div style={{float:"left", marginLeft:"20px"}}>
                                <div>Date To:</div>
                        <DatePicker
                            selected={selectedDateTo}
                            onChange={date => setSelectedDateTo(date)}
                            showMonthDropdown={true}
                            showYearDropdown={true}
                            minDate={new Date((new Date().getFullYear()+4),11,31)}
                            dateFormat="yyyy-MM-dd" />
                            </div>
                            <div style={{float:"left", marginLeft:"20px"}}>
                                <div>MMA:</div>
                            <input placeholder={"Minimali alga"} onChange={(evt) => { setMinimumWage(evt.target.value); }} />
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={handleCloseLong}>
                            Close
                        </Button>
                        {showNextButton(selectedDateFrom, selectedDateTo, minimumWage)}
                    </Modal.Footer>
                </Modal>
            </>
        );
    }

    const changas = () =>{
        if(buttonas === false){
           setButtonas(true);
        }else{
            handleClose();
            setButtonas(false);
        }
    };

    const changas2 = () =>{
        if(buttonas2 === false){
            setButtonas2(true);
        }else{
            handleCloseLong();
            setButtonas2(false);
        }
    };


    const secondSelectForObjet=()=>{
        if(selectedBuValue !== null){


            return(<div>
                    <label><strong>Choose House</strong></label>
                    <AsyncSelect
                        cacheOptions
                        defaultOptions
                        value={selectedObjectValue}
                        getOptionLabel={e => {if(e.houseLetter==null){return(e.street +" "+ e.houseNumber);}else{return (e.street +" "+ e.houseNumber + e.houseLetter);}} }
                        getOptionValue={e => e.id}
                        loadOptions={loadOptions} //loadOptions
                        onInputChange={handleInputChange}
                        onChange={handleChange}
                    />

                </div>


            );

        }
    }

    function showGenerateButtons(selectedObject, selectedBusinessUnit){
        if(selectedObject!=null && selectedBusinessUnit!=null){
            return(
                <div>
                <div style={{float:"right", margin:"20px"}}>
                    <button className={"btn btn-success"} onClick={handleShow}>Generate Short Term Plan</button>
                </div>


            <div style={{float:"right", margin:"20px"}}>
                <button className={"btn btn-success"} onClick={handleShowLong}>Generate Long Term Plan</button>
            </div>
                </div>
            )
        }
    }

    const mygtukas=()=>{
        if(buttonas === false && buttonas2 === false){
            return (
                <div className="App">
                    <div style={{marginLeft:"20px", marginRight:"20px"}}>

                        <label><strong>Choose Business Unit</strong></label>
                        <AsyncSelect
                            cacheOptions
                            defaultOptions
                            value={selectedBuValue}
                            getOptionLabel={e=> e.name}
                            getOptionValue={e=> e.id}
                            loadOptions={loadBuOptions}
                            onInputChange={handleInputBuChange}
                            onChange={handleBuChange}
                        />
                         <div style={{marginTop:"20px"}}>
                            {secondSelectForObjet()}
                         </div>
                    </div>


                    {showGenerateButtons(selectedObjectValue, selectedBuValue)}


                    {modalas()}
                    {modalasLong()}
                </div>

            );
        }else if(buttonas === true ){
            return (
                <div style={{width: "100%"}}>

                    <div >
                        <button className={"btn btn-success"} onClick={changas} style={{margin:"0 auto", display:"block"}}>Back To Selection</button>
                        {showObjectInfo()}
                    </div>

                </div>
            );
        }else if(buttonas2=== true){
            return(
            <div style={{width: "100%"}}>
                <div >
                    <button className={"btn btn-success"} onClick={changas2} style={{margin:"0 auto", display:"block"}}>Back To Selection</button>
                    {showLongTermInfo()}
                </div>
            </div>
            );
        }
    }


    const handleChange = value => {
        setSelectedObjectValue(value);
    };


    const handleBuChange = value2 =>{
        setSelectedBuValue(value2);
    };


    const loadOptions = (inputValue) => {

            return axios.get(`http://localhost:8080/ataskaita/api/live/object/search?house=${inputValue}&bu=${selectedBuValue.id}`, {headers: authHeader()})
                .then(res => res.data);
    };



    const loadBuOptions = (inputBuValue) => {
        return axios.get(`http://localhost:8080/ataskaita/api/live/business/search?bu=${inputBuValue}`, { headers: authHeader() })
            .then(resas => resas.data);
    }



    const showObjectInfo = () =>{
        if(selectedObjectValue != null){
            return <GetObjectInfoForDocument
                reload={buttonas}
                object={selectedObjectValue.id}
                selectedDateShort={selectedDateShort}
            />;
        }
    }

    const showLongTermInfo=()=>{
        if(selectedObjectValue != null){
            return <GetObjectInfoForDocumentLong
                reload={buttonas2}
                object={selectedObjectValue.id}
                selectedDateFrom={selectedDateFrom}
                selectedDateTo={selectedDateTo}
                minimumWage={minimumWage}
                />
        }
    }


    return (
        <div>
            {mygtukas()}
        </div>

    );
}

export default GetSearchObject;