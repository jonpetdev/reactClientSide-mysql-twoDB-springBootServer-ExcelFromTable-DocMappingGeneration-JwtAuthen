import React, {Component}  from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import Logo from "./loadingimage.svg";
import GetFailiukas from "./GetFailiukas";




class GetObjectInfoForDocument extends Component{
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            object: null,
            reload: false,
            loading: true,
            selectedDateS: props.selectedDateShort,

        };



    }


    loadData = (object, year) =>{

        axios.get(`http://localhost:8080/ataskaita/api/live/object?house=${object}&year=${year}` , { headers: authHeader() })
            .then(response => response.data)
            .then(responseData => {
                this.setState({
                    data: responseData,
                    loading: false,
                });

            });
    }


    componentDidMount() {
        if(this.props.reload ===true) {
            this.loadData(this.props.object, this.props.selectedDateShort.getFullYear().toString());
        }
    }


    render() {

        let docInfo=[];
        let selectedDate,autoGenNo,businessUnitAddress,selectedDateYear,houseArea,constructionYear="-", floorCount, flatCount, nonFlatCount,
            totalArea,area, landArea, propRegDate="-",tariff1_1,tariff1_2,tariff2_1, tariff2_2,tariff3_1 ,tariff3_2, tariff4_1, tariff4_2,
            tariff5_1, tariff5_2, tariff6_1, tariff6_2, tariff7_1, tariff7_2, tariff8_1, tariff8_2, tariff9_1, tariff9_2, sum1,sum2,sum3,
            accFundTariff, accFundBalance, planuojamu3punktoSum, antroSkyr3,antroSkyr4,antroSkyr5, houseAddress,businessUnitName;
           let antroSkyrPastabos="-", pirmoSkyr3punktoPastabos="-",
            pirmoSkyr1Pastabos1="-",pirmoSkyr1Pastabos2="-",pirmoSkyr1Pastabos3="-",pirmoSkyr1Pastabos4="-",pirmoSkyr1Pastabos5="-",pirmoSkyr1Pastabos6="-",
            pirmoSkyr1Pastabos7="-",pirmoSkyr1Pastabos8="-",pirmoSkyr1Pastabos9="-";

        let ticketList= [];








function gettiname() {



    docInfo={
        houseAddress: houseAddress,
        selectedDate: selectedDate,
        autoGenNo: autoGenNo,
        businessUnitAddress: businessUnitAddress,
        businessUnitName: businessUnitName,
        selectedDateYear:selectedDateYear,
        houseArea: houseArea,
        constructionYear: constructionYear,
        floorCount: floorCount,
        flatCount: flatCount,
        nonFlatCount: nonFlatCount,
        totalArea: totalArea,
        area: area,
        landArea: landArea,
        propRegDate: propRegDate,
        tariff1_1: tariff1_1,
        tariff1_2: tariff1_2,
        tariff2_1: tariff2_1,
        tariff2_2: tariff2_2,
        tariff3_1: tariff3_1,
        tariff3_2: tariff3_2,
        tariff4_1: tariff4_1,
        tariff4_2: tariff4_2,
        tariff5_1: tariff5_1,
        tariff5_2: tariff5_2,
        tariff6_1: tariff6_1,
        tariff6_2: tariff6_2,
        tariff7_1: tariff7_1,
        tariff7_2: tariff7_2,
        tariff8_1: tariff8_1,
        tariff8_2: tariff8_2,
        tariff9_1: tariff9_1,
        tariff9_2: tariff9_2,
        sum1: sum1,
        sum2: sum2,
        sum3: sum3,
        ticket: ticketList,
        accFundTariff: accFundTariff,
        accFundBalance: accFundBalance,
        planuojamu3punktoSum: planuojamu3punktoSum,
        antroSkyr3: antroSkyr3,
        antroSkyr4: antroSkyr4,
        antroSkyr5: antroSkyr5,
        antroSkyrPastabos: antroSkyrPastabos,
        pirmoSkyr3punktoPastabos: pirmoSkyr3punktoPastabos,
        pirmoSkyr1Pastabos1:  pirmoSkyr1Pastabos1,
        pirmoSkyr1Pastabos2: pirmoSkyr1Pastabos2,
        pirmoSkyr1Pastabos3: pirmoSkyr1Pastabos3 ,
        pirmoSkyr1Pastabos4: pirmoSkyr1Pastabos4,
        pirmoSkyr1Pastabos5: pirmoSkyr1Pastabos5 ,
        pirmoSkyr1Pastabos6: pirmoSkyr1Pastabos6 ,
        pirmoSkyr1Pastabos7:  pirmoSkyr1Pastabos7,
        pirmoSkyr1Pastabos8:  pirmoSkyr1Pastabos8,
        pirmoSkyr1Pastabos9:  pirmoSkyr1Pastabos9,
    }

    const data=new GetFailiukas(docInfo);

    return(data.onClickReport());

}

        if (this.state.loading === true) {
            return (
                <div style={{width:"100%",
                    height:"100%",
                    display: "flex" ,
                    justifyContent: "center",
                    backgroundColor:"rgba(0, 0, 0, 0.53)",
                    position:"fixed",
                    top:"0px",
                    left:"0px",
                    zIndex:"999999999",
                }   }>
                    <img src={Logo} alt={"logo"} />
                </div>
            );

        } else {


            let planSkaicius= 0;
            let bendraAntroPunktoSuma=0;




            return (<div>


                    <div  className={"elemClass"}>
                     {this.state.data.map(ob =>{

                         if(ob.tariff==null){
                             return (<p>
                                Nėra Tarifo Duomenų Šiam Objektui!
                             </p>)
                         }else {

                             ob.planningTickets.map(plan => {

                                 if(plan.price==null || plan.price==""){

                                 }else{
                                     bendraAntroPunktoSuma = bendraAntroPunktoSuma + parseInt(plan.price);
                                 }

                             });

                             houseAddress = "" + ob.nfqObject.street + " " + ob.nfqObject.houseNumber + ob.nfqObject.houseLetter;


                             selectedDate = this.state.selectedDateS.getFullYear() + "-" + (this.state.selectedDateS.getMonth() + 1) + "-" + this.state.selectedDateS.getDate();
                             autoGenNo = ob.nfqObject.street.toString().substring(0, 3).toUpperCase() + this.state.selectedDateS.getFullYear() + (Math.floor(Math.random() * 9999) + 1000) + ob.nfqObject.houseNumber;
                             businessUnitAddress = ob.oroBusinessUnit.address;
                             businessUnitName = ob.oroBusinessUnit.name;
                             selectedDateYear = this.state.selectedDateS.getFullYear();
                             houseArea = ob.nfqObject.area.toString();
                             constructionYear = ob.nfqObject.constructionYear;
                             floorCount = ob.nfqObject.floorCount;
                             flatCount = ob.flatCount;
                             nonFlatCount = ob.nonFlatCount;
                             totalArea = ob.totalArea;
                             area = ob.nfqObject.area;
                             landArea = ob.tariff.zemesSklypoPlotas;
                             propRegDate = ob.tariff.registacijosData;
                             tariff1_1 = Number(ob.tariff.commonUseAdministrationTariff).toFixed(4);
                             tariff1_2 = Number(ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff2_1 = Number(ob.tariff.maintenanceTariff).toFixed(4);
                             tariff2_2 = Number(ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff3_1 = Number(ob.tariff.heatingAndHeatingSystemMaintenanceTariff).toFixed(4);
                             tariff3_2 = Number(ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff4_1 = Number(ob.tariff.elevatorElectricityTariff).toFixed(4);
                             tariff4_2 = Number(ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff5_1 = Number(ob.tariff.elevatorMaintenanceTariff).toFixed(4);
                             tariff5_2 = Number(ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff6_1 = Number(ob.tariff.electricityForCommonUsageTariff).toFixed(4);
                             tariff6_2 = Number(ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff7_1 = Number(ob.tariff.commonPremisesCleaningTariff).toFixed(4);
                             tariff7_2 = Number(ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff8_1 = Number(ob.tariff.territoryMaintenanceTariff).toFixed(4);
                             tariff8_2 = Number(ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2);
                             tariff9_1 = Number(ob.tariff.otherServicesTariff).toFixed(4);
                             tariff9_2 = Number(ob.tariff.otherServicesTariff * 12 * ob.nfqObject.area).toFixed(2);
                             sum1 = Number(
                                 (ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.otherServicesTariff * 12 * ob.nfqObject.area)).toFixed(2);
                             sum2 = Number(bendraAntroPunktoSuma).toFixed(2);
                             sum3 = Number(
                                 (ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.otherServicesTariff * 12 * ob.nfqObject.area) +
                                 (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) +
                                 (bendraAntroPunktoSuma)).toFixed(2);
                             accFundTariff = Number(ob.tariff.accumulatedFundTariff).toFixed(4);
                             accFundBalance = Number(ob.tariff.accumulatedFundBalance).toFixed(2);
                             planuojamu3punktoSum = Number(ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area).toFixed(2);
                             antroSkyr3 = Number(
                                 (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area)).toFixed(2);
                             antroSkyr4 = Number(
                                 (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) +
                                 (bendraAntroPunktoSuma)).toFixed(2);
                             antroSkyr5 = Number(
                                 (ob.tariff.accumulatedFundBalance) +
                                 (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) -
                                 ((ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) + (bendraAntroPunktoSuma))).toFixed(2);
                         }


                         return (
                             <div key={ob.nfqObject.id}>
                                 <p>Documento numeris: <strong>{autoGenNo}</strong></p>
                                 <p>Dokumento data: <strong>{selectedDate}</strong> </p>
                                 <p>Adresas: <strong> {ob.nfqObject.street} {ob.nfqObject.houseNumber} {ob.nfqObject.houseLetter}</strong></p>
                                 <p>Statybos metai: <input onChange={(evt) => { constructionYear= evt.target.value; }} defaultValue={constructionYear}/></p>
                                 <p>Aukstu sk.: <input onChange={(evt) => { floorCount= evt.target.value; }} defaultValue={floorCount}/></p>
                                 <p>Butu sk.: <strong>{ob.flatCount}</strong></p>
                                 <p>Kitu patalpu sk.: <strong>{ob.nonFlatCount}</strong></p>
                                 <p>Bendras plotas: <input onChange={(evt) => { totalArea= evt.target.value; }} defaultValue={totalArea}/></p>
                                 <p>Naudingas plotas: <strong>{ob.nfqObject.area}</strong></p>
                                 <p>Zemes sklypo plotas: <input onChange={(evt) => { landArea= evt.target.value; }} defaultValue={landArea}/></p>
                                 <p>Nekilnojamo turto registre data: <input onChange={(evt) => { propRegDate= evt.target.value; }} defaultValue={propRegDate}/></p>

                                 <br/>
                                 <h3>1. Namo išlaikymo išlaidos</h3>

                                 <table className={"table table-sm table-condensed tableBorder"}>
                                     <thead className={"thead-dark"}>
                                     <tr>
                                         <th>Eil. Nr.</th>
                                         <th>Planuojamų išlaidų pavadinimas</th>
                                         <th>Tarifas arba išlaidos (su PVM)</th>
                                         <th>Planuojama metinė išlaidų suma, Eur</th>
                                         <th>Pastabos</th>
                                     </tr>
                                     </thead>
                                     <tbody>
                                     <tr>
                                         <td>1.1</td>
                                         <td>Bendro naudojimo objektų administravimo</td>
                                         <td>{Number(ob.tariff.commonUseAdministrationTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"}  key={1} placeholder={"Pastabos"} id={"p1"} onChange={(evt) => { pirmoSkyr1Pastabos1= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.2</td>
                                         <td>Techninės priežiūros (išskyrus šildymo ir karšto vandens sistemų ir liftų)</td>
                                         <td>{Number(ob.tariff.maintenanceTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={2} placeholder={"Pastabos"} id={"p2"} onChange={(evt) => { pirmoSkyr1Pastabos2= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.3</td>
                                         <td>Šildymo ir karšto vandens sistemų priežiūros</td>
                                         <td>{Number(ob.tariff.heatingAndHeatingSystemMaintenanceTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={3} placeholder={"Pastabos"} id={"p3"} onChange={(evt) => { pirmoSkyr1Pastabos3= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.4</td>
                                         <td>Liftų naudojimo (liftų elektros energija)</td>
                                         <td>{Number(ob.tariff.elevatorElectricityTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={4} placeholder={"Pastabos"} id={"p4"} onChange={(evt) => { pirmoSkyr1Pastabos4= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.5</td>
                                         <td>Liftų priežiūros</td>
                                         <td>{Number(ob.tariff.elevatorMaintenanceTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={5} placeholder={"Pastabos"} id={"p5"} onChange={(evt) => { pirmoSkyr1Pastabos5= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.6</td>
                                         <td>Elektros energijos bendrosioms reikmėms (išskyrus liftų)</td>
                                         <td>{Number(ob.tariff.electricityForCommonUsageTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={6} placeholder={"Pastabos"} id={"p6"} onChange={(evt) => { pirmoSkyr1Pastabos6= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.7</td>
                                         <td>Bendro naudojimo patalpų valymo</td>
                                         <td>{Number(ob.tariff.commonPremisesCleaningTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={7} placeholder={"Pastabos"} id={"p7"} onChange={(evt) => { pirmoSkyr1Pastabos7= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.8</td>
                                         <td>Žemės sklypo priežiūros</td>
                                         <td>{Number(ob.tariff.territoryMaintenanceTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"} key={8} placeholder={"Pastabos"} id={"p8"} onChange={(evt) => { pirmoSkyr1Pastabos8= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td>1.9</td>
                                         <td>Kitų planuojamų teikti paslaugų</td>
                                         <td>{Number(ob.tariff.otherServicesTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.otherServicesTariff * 12  * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"}  key={9} placeholder={"Pastabos"} id={"p9"}  onChange={(evt) => { pirmoSkyr1Pastabos9= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td></td>
                                         <td>Iš viso pagal šį punktą planuojama išlaidų</td>
                                         <td></td>
                                         <td>{Number(
                                             (ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.otherServicesTariff * 12 * ob.nfqObject.area)).toFixed(2)
                                         }</td>
                                         <td></td>
                                     </tr>


                                     </tbody>
                                 </table>

                                 <br/>
                                 <h3>2. Išlaidos planiniams bendrojo naudojimo objektų atnaujinimo darbams</h3>

                                 <table className={"table table-sm table-condensed"}>
                                     <thead className={"thead-dark"}>
                                     <tr>
                                         <th>Eil. Nr.</th>
                                         <th>Planuojamų išlaidų pavadinimas</th>
                                         <th>Tarifas arba išlaidos (su PVM)</th>
                                         <th>Planuojama metinė išlaidų suma, Eur</th>
                                         <th>Work Deadline</th>
                                         <th>ticket id</th>
                                         <th>Flow kategorija</th>
                                         <th>Pastabos</th>
                                     </tr>
                                     </thead>
                                     <tbody>
                                     {ob.planningTickets.map(plan=>{
                                         planSkaicius++;

                                         let preliminaryPrice=0.0;
                                         let pastabosTicket="";

                                         if(plan.price==null || plan.price==""){
                                             preliminaryPrice=0.0;
                                         }else{
                                             preliminaryPrice=Number(plan.price);
                                         }

                                         ticketList=ticketList.concat({id: plan.id,title: plan.title, price: preliminaryPrice, pastabos: pastabosTicket, sk:planSkaicius});

                                         function deadlinas(date) {
                                             if (date > new Date(plan.workDeadline) || new Date(plan.workDeadline)> new Date(date).setFullYear(date.getFullYear()+1)) {
                                                 return(
                                                     <td style={{color:"red"}}>{new Date(plan.workDeadline).getFullYear()+"-"+(new Date(plan.workDeadline).getMonth()+1)+"-"+ new Date(plan.workDeadline).getDate()}</td>
                                                 )
                                             } else {
                                                return (
                                                    <td>{new Date(plan.workDeadline).getFullYear()+"-"+(new Date(plan.workDeadline).getMonth()+1)+"-"+ new Date(plan.workDeadline).getDate()}</td>
                                                )
                                             }
                                         }

                                         function preliminaryPriceFunc(prelPrice){
                                             if(prelPrice===0.0) {
                                                 return (
                                                     <td style={{color: "red"}}>{prelPrice}</td>
                                                 );
                                             }else{
                                                     return(
                                                         <td>{prelPrice}</td>
                                                     );
                                             }
                                         }

                                         return(
                                             <tr key={plan.id}>
                                                 <td>2.{planSkaicius}</td>
                                                 <td>{plan.title}</td>
                                                 <td> - - </td>
                                                 {preliminaryPriceFunc(preliminaryPrice)}
                                                 {deadlinas(this.state.selectedDateS)}
                                                 <td><a href={"https://fms.civinity.lt/tickets/view/"+plan.id} target={"_blank"} rel="noopener noreferrer">{plan.id}</a></td>
                                                 <td>{plan.ltFlowCategory}</td>
                                                 <td><textarea rows={"4"}  key={plan.id} placeholder={"Pastabos"} onChange={(evt) => { ticketList.find(x => x.id === plan.id).pastabos= evt.target.value; }}/></td>
                                             </tr>
                                         );
                                     })}

                                     <tr>
                                         <td></td>
                                         <td>iš viso pagal šį punktą planuojama išlaidų:</td>
                                         <td></td>
                                         <td>{Number(bendraAntroPunktoSuma).toFixed(2)}</td>
                                         <td></td>
                                         <td></td>
                                     </tr>
                                     </tbody>
                                 </table>

                                 <br/>

                                 <h3>3. Planuojamas lėšų rezervas nenumatytiems namo bendrojo naudojimo objektų remonto darbamas</h3>
                                 <table className={"table table-sm table-condensed"}>
                                     <thead className={"thead-dark"}>
                                     <tr>
                                         <th>Eil. Nr.</th>
                                         <th>Planuojamų išlaidų pavadinimas</th>
                                         <th>Tarifas arba išlaidos (su PVM)</th>
                                         <th>Planuojama metinė išlaidų suma, Eur</th>
                                         <th>Pastabos</th>
                                     </tr>
                                     </thead>
                                     <tbody>
                                     <tr>
                                         <td></td>
                                         <td>(defektų, deformacijų šalinimas, avarijų likvidavimas)</td>
                                         <td>{Number(ob.tariff.accumulatedFundTariff).toFixed(4)}</td>
                                         <td>{Number(ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area).toFixed(2)}</td>
                                         <td><textarea rows={"4"}  placeholder={"Pastabos"} onChange={(evt) => { pirmoSkyr3punktoPastabos= evt.target.value; }}/></td>
                                     </tr>
                                     <tr>
                                         <td></td>
                                         <td>iš viso planuojamų išlaidų (pagal 1, 2 ir 3 punktus)</td>
                                         <td></td>
                                         <td>{Number(
                                             (ob.tariff.commonUseAdministrationTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.maintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.heatingAndHeatingSystemMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.elevatorElectricityTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.elevatorMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.electricityForCommonUsageTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.commonPremisesCleaningTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.territoryMaintenanceTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.otherServicesTariff * 12 * ob.nfqObject.area) +
                                             (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) +
                                             (bendraAntroPunktoSuma)).toFixed(2)
                                         }</td>
                                     </tr>
                                     </tbody>
                                 </table>

                                 <br/>

                                 <h2>II Skyrius</h2>
                                 <h3>Lėšų kaupimo ir jų išlaidų suvestinė</h3>

                                 <table className={"table table-sm table-condensed"}>
                                     <thead className={"thead-dark"}>
                                     <tr>
                                         <th>Pavadinimas</th>
                                         <th>Sukauptų lėšų likutis kalendorinių metų sausio 1 d. Eur</th>
                                         <th>Planuojama sukaupti lėšų, Eur/metus</th>
                                         <th>Planuojama išlaidų ir lėšų rezervo suma, Eur</th>
                                         <th>Planuojamas lėšų likutis metų pabaigoje, Eur</th>
                                         <th>Pastabos</th>
                                     </tr>
                                     </thead>
                                     <tbody>
                                     <tr>
                                         <td>Kaupiamos lėšos planiniams darbams</td>
                                         <td>{Number(ob.tariff.accumulatedFundBalance).toFixed(2)}</td>
                                         <td>{Number(
                                             (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area)).toFixed(2)
                                         }</td>
                                         <td>{Number(
                                             (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area)+
                                             (bendraAntroPunktoSuma)).toFixed(2)
                                         }</td>
                                         <td>{Number(
                                             (ob.tariff.accumulatedFundBalance) +
                                             (ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area) -
                                             ((ob.tariff.accumulatedFundTariff * 12 * ob.nfqObject.area)+(bendraAntroPunktoSuma))).toFixed(2)
                                         }</td>
                                         <td><textarea rows={"4"}  placeholder={"Pastabos"} id={"p2sp"} onChange={(evt) => { antroSkyrPastabos= evt.target.value; }} /></td>
                                     </tr>
                                     </tbody>
                                 </table>


                                 <div style={{margin: "50px"}}>
                                     <button className={"btn btn-primary"} onClick={gettiname}>Export .docx</button>
                                 </div>

                             </div>
                         );
                     }

                     ) }
                    </div>


                </div>
            );
        }
    }


}
export default GetObjectInfoForDocument;